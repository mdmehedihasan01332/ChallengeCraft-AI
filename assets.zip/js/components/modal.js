/**
 * Modal Component for ChallengeCraft AI
 */

const modalComponent = {
    /**
     * Container for modals
     */
    container: null,
    
    /**
     * Current active modal
     */
    activeModal: null,
    
    /**
     * Default modal options
     */
    defaultOptions: {
        title: 'Modal',
        content: '',
        closable: true,
        backdrop: true,
        size: 'medium', // small, medium, large
        buttons: [
            {
                text: 'Close',
                action: 'close',
                className: 'btn-secondary'
            }
        ],
        onClose: null
    },
    
    /**
     * Initialize the modal component
     */
    init() {
        // Get or create container
        this.container = document.getElementById('modalContainer');
        
        if (!this.container) {
            this.container = document.createElement('div');
            this.container.id = 'modalContainer';
            this.container.className = 'modal-container';
            document.body.appendChild(this.container);
        }
        
        // Add event listener for backdrop click
        this.container.addEventListener('click', (e) => {
            // Only close if clicking directly on the backdrop, not on modal content
            if (e.target === this.container && this.activeModal?.options.backdrop) {
                this.hide();
            }
        });
        
        // Add event listener for ESC key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isVisible() && this.activeModal?.options.closable) {
                this.hide();
            }
        });
    },
    
    /**
     * Check if modal is visible
     * @returns {boolean} Whether the modal is visible
     */
    isVisible() {
        return this.container && this.container.classList.contains('active');
    },
    
    /**
     * Show a modal
     * @param {Object} options - Modal options
     * @param {string} [options.title] - The modal title
     * @param {string|HTMLElement} [options.content] - The modal content
     * @param {boolean} [options.closable] - Whether the modal can be closed by the user
     * @param {boolean} [options.backdrop] - Whether clicking the backdrop closes the modal
     * @param {string} [options.size] - The modal size (small, medium, large)
     * @param {Array} [options.buttons] - Array of button configurations
     * @param {Function} [options.onClose] - Callback to run when modal is closed
     * @returns {Object} The modal instance
     */
    show(options = {}) {
        // Merge with default options
        const modalOptions = {
            ...this.defaultOptions,
            ...options,
            buttons: options.buttons || this.defaultOptions.buttons
        };
        
        // Store options
        this.activeModal = {
            element: null,
            options: modalOptions
        };
        
        // Create modal element
        const modal = document.createElement('div');
        modal.className = `modal modal-${modalOptions.size}`;
        
        // Create header
        const header = document.createElement('div');
        header.className = 'modal-header';
        
        const title = document.createElement('h3');
        title.className = 'modal-title';
        title.textContent = modalOptions.title;
        header.appendChild(title);
        
        if (modalOptions.closable) {
            const closeButton = document.createElement('button');
            closeButton.className = 'modal-close';
            closeButton.innerHTML = '&times;';
            closeButton.setAttribute('aria-label', 'Close');
            closeButton.addEventListener('click', () => this.hide());
            header.appendChild(closeButton);
        }
        
        modal.appendChild(header);
        
        // Create body
        const body = document.createElement('div');
        body.className = 'modal-body';
        
        if (typeof modalOptions.content === 'string') {
            body.innerHTML = modalOptions.content;
        } else if (modalOptions.content instanceof HTMLElement) {
            body.appendChild(modalOptions.content);
        }
        
        modal.appendChild(body);
        
        // Create footer with buttons if there are any
        if (modalOptions.buttons && modalOptions.buttons.length > 0) {
            const footer = document.createElement('div');
            footer.className = 'modal-footer';
            
            modalOptions.buttons.forEach(button => {
                const btn = document.createElement('button');
                btn.className = `btn ${button.className || ''}`;
                btn.textContent = button.text;
                
                btn.addEventListener('click', () => {
                    if (button.action === 'close') {
                        this.hide();
                    } else if (typeof button.action === 'function') {
                        button.action();
                    }
                });
                
                footer.appendChild(btn);
            });
            
            modal.appendChild(footer);
        }
        
        // Store reference to the modal element
        this.activeModal.element = modal;
        
        // Clear any existing modals
        this.container.innerHTML = '';
        
        // Add to the container
        this.container.appendChild(modal);
        
        // Show the container
        this.container.classList.add('active');
        
        // Add fade-in class to modal
        setTimeout(() => {
            modal.classList.add('fade-in');
        }, 10);
        
        return this.activeModal;
    },
    
    /**
     * Hide the current modal
     */
    hide() {
        if (!this.activeModal) {
            return;
        }
        
        // Call onClose callback if exists
        if (typeof this.activeModal.options.onClose === 'function') {
            this.activeModal.options.onClose();
        }
        
        // Add fade-out class
        this.activeModal.element.classList.add('fade-out');
        
        // Hide container after animation
        setTimeout(() => {
            this.container.classList.remove('active');
            this.container.innerHTML = '';
            this.activeModal = null;
        }, 300);
    },
    
    /**
     * Show a confirmation modal
     * @param {string} message - The confirmation message
     * @param {Function} onConfirm - Callback on confirmation
     * @param {Function} [onCancel] - Callback on cancellation
     * @param {Object} [options] - Additional modal options
     * @returns {Object} The modal instance
     */
    confirm(message, onConfirm, onCancel = null, options = {}) {
        return this.show({
            title: options.title || 'Confirmation',
            content: `<div class="confirmation-message">${message}</div>`,
            buttons: [
                {
                    text: options.confirmText || 'Confirm',
                    action: () => {
                        this.hide();
                        if (typeof onConfirm === 'function') {
                            onConfirm();
                        }
                    },
                    className: options.confirmClass || 'btn-primary'
                },
                {
                    text: options.cancelText || 'Cancel',
                    action: () => {
                        this.hide();
                        if (typeof onCancel === 'function') {
                            onCancel();
                        }
                    },
                    className: options.cancelClass || 'btn-secondary'
                }
            ],
            size: options.size || 'small',
            ...options
        });
    },
    
    /**
     * Show an alert modal
     * @param {string} message - The alert message
     * @param {Function} [onClose] - Callback on close
     * @param {Object} [options] - Additional modal options
     * @returns {Object} The modal instance
     */
    alert(message, onClose = null, options = {}) {
        return this.show({
            title: options.title || 'Alert',
            content: `<div class="alert-message">${message}</div>`,
            buttons: [
                {
                    text: options.closeText || 'OK',
                    action: 'close',
                    className: options.closeClass || 'btn-primary'
                }
            ],
            onClose: onClose,
            size: options.size || 'small',
            ...options
        });
    },
    
    /**
     * Show a prompt modal
     * @param {string} message - The prompt message
     * @param {Function} onSubmit - Callback on submit (receives input value)
     * @param {Function} [onCancel] - Callback on cancellation
     * @param {Object} [options] - Additional modal options
     * @returns {Object} The modal instance
     */
    prompt(message, onSubmit, onCancel = null, options = {}) {
        const inputId = 'modal-prompt-input-' + helpers.generateId();
        
        const content = `
            <div class="prompt-message">${message}</div>
            <div class="prompt-input">
                <input type="${options.inputType || 'text'}" 
                       id="${inputId}" 
                       class="form-control" 
                       value="${options.defaultValue || ''}"
                       placeholder="${options.placeholder || ''}"
                       ${options.required ? 'required' : ''}>
            </div>
        `;
        
        const handleSubmit = () => {
            const inputElement = document.getElementById(inputId);
            if (inputElement) {
                const value = inputElement.value;
                if (options.required && !value) {
                    inputElement.classList.add('shake');
                    setTimeout(() => {
                        inputElement.classList.remove('shake');
                    }, 600);
                    return;
                }
                
                this.hide();
                if (typeof onSubmit === 'function') {
                    onSubmit(value);
                }
            }
        };
        
        const modal = this.show({
            title: options.title || 'Prompt',
            content: content,
            buttons: [
                {
                    text: options.submitText || 'Submit',
                    action: handleSubmit,
                    className: options.submitClass || 'btn-primary'
                },
                {
                    text: options.cancelText || 'Cancel',
                    action: () => {
                        this.hide();
                        if (typeof onCancel === 'function') {
                            onCancel();
                        }
                    },
                    className: options.cancelClass || 'btn-secondary'
                }
            ],
            size: options.size || 'small',
            ...options
        });
        
        // Focus the input field
        setTimeout(() => {
            const inputElement = document.getElementById(inputId);
            if (inputElement) {
                inputElement.focus();
                
                // Add enter key listener
                inputElement.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') {
                        handleSubmit();
                    }
                });
            }
        }, 100);
        
        return modal;
    }
};

// Initialize modal component when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    modalComponent.init();
});

// Make modal component available globally
window.modalComponent = modalComponent; 