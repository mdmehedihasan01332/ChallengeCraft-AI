/**
 * Notification Component for ChallengeCraft AI
 */

const notificationComponent = {
    /**
     * Container for notifications
     */
    container: null,
    
    /**
     * Map of active notifications
     */
    activeNotifications: new Map(),
    
    /**
     * Default notification options
     */
    defaultOptions: {
        type: 'info',          // info, success, warning, error
        duration: 5000,        // duration in ms (0 for permanent)
        closable: true,        // whether notification can be closed
        position: 'top-right', // top-right, top-left, bottom-right, bottom-left
    },
    
    /**
     * Initialize the notification component
     */
    init() {
        // Get or create container
        this.container = document.getElementById('notificationContainer');
        
        if (!this.container) {
            this.container = document.createElement('div');
            this.container.id = 'notificationContainer';
            this.container.className = 'notifications';
            document.body.appendChild(this.container);
        }
    },
    
    /**
     * Show a notification
     * @param {string} message - The notification message
     * @param {string} [type] - The notification type (info, success, warning, error)
     * @param {number} [duration] - The duration to show the notification (0 for permanent)
     * @param {boolean} [isLoading=false] - Whether this is a loading notification
     * @returns {string} The ID of the notification
     */
    show(message, type = 'info', duration, isLoading = false) {
        const id = 'notification-' + helpers.generateId();
        const options = {
            ...this.defaultOptions,
            type: type || this.defaultOptions.type,
            duration: duration !== undefined ? duration : this.defaultOptions.duration,
            isLoading: isLoading
        };
        
        // Create notification element
        const notification = document.createElement('div');
        notification.id = id;
        notification.className = `notification ${options.type}`;
        
        // Initial state for animation
        notification.style.opacity = '0';
        notification.style.transform = 'translateY(-20px)';
        
        // Add loading spinner for loading notifications
        const content = document.createElement('div');
        content.className = 'notification-content';
        
        if (isLoading) {
            const loadingIcon = document.createElement('div');
            loadingIcon.className = 'spinner spinner-sm';
            notification.appendChild(loadingIcon);
            // Add pulse animation to loading notifications
            loadingIcon.style.animation = 'spin 1s linear infinite, pulse 2s ease-in-out infinite';
            options.closable = false;
            options.duration = 0;
        }
        
        // Add icon based on type
        const iconContainer = document.createElement('div');
        iconContainer.className = 'notification-icon';
        
        let iconHtml = '';
        switch (options.type) {
            case 'success':
                iconHtml = '<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18Z" stroke="currentColor" stroke-width="2"/><path d="M7 10L9 12L13 8" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
                break;
            case 'warning':
                iconHtml = '<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M8.4 2.7c.7-1.1 2.5-1.1 3.2 0l8.2 13.1c.7 1.1-.2 2.6-1.6 2.6H1.8c-1.4 0-2.3-1.5-1.6-2.6L8.4 2.7z" stroke="currentColor" stroke-width="2"/><path d="M10 8v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="10" cy="15" r="1" fill="currentColor"/></svg>';
                break;
            case 'error':
                iconHtml = '<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18Z" stroke="currentColor" stroke-width="2"/><path d="M7 7L13 13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M13 7L7 13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
                break;
            default:
                iconHtml = '<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10C2 14.4183 5.58172 18 10 18Z" stroke="currentColor" stroke-width="2"/><path d="M10 6v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="10" cy="13" r="1" fill="currentColor"/></svg>';
        }
        
        iconContainer.innerHTML = iconHtml;
        content.appendChild(iconContainer);
        
        // Add title based on type
        const title = document.createElement('div');
        title.className = 'notification-title';
        
        switch (options.type) {
            case 'success':
                title.textContent = 'Success';
                break;
            case 'warning':
                title.textContent = 'Warning';
                break;
            case 'error':
                title.textContent = 'Error';
                break;
            default:
                title.textContent = 'Information';
        }
        
        content.appendChild(title);
        
        // Add message
        const messageElement = document.createElement('div');
        messageElement.className = 'notification-message';
        messageElement.textContent = message;
        content.appendChild(messageElement);
        
        notification.appendChild(content);
        
        // Add close button if closable
        if (options.closable) {
            const closeButton = document.createElement('div');
            closeButton.className = 'notification-close';
            closeButton.innerHTML = '<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M13 1L1 13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M1 1L13 13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
            closeButton.addEventListener('click', () => this.hide(id));
            notification.appendChild(closeButton);
        }
        
        // Store reference to the notification
        this.activeNotifications.set(id, {
            element: notification,
            timer: null,
            options: options
        });
        
        // Add to the container
        this.container.appendChild(notification);
        
        // Trigger animation
        setTimeout(() => {
            notification.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
            notification.style.opacity = '1';
            notification.style.transform = 'translateY(0)';
        }, 10);
        
        // Set timeout to remove notification after duration if not permanent
        if (options.duration > 0) {
            const timer = setTimeout(() => this.hide(id), options.duration);
            this.activeNotifications.get(id).timer = timer;
        }
        
        return id;
    },
    
    /**
     * Show a success notification
     * @param {string} message - The notification message
     * @param {number} [duration] - The duration to show the notification
     * @returns {string} The ID of the notification
     */
    success(message, duration) {
        return this.show(message, 'success', duration);
    },
    
    /**
     * Show a warning notification
     * @param {string} message - The notification message
     * @param {number} [duration] - The duration to show the notification
     * @returns {string} The ID of the notification
     */
    warning(message, duration) {
        return this.show(message, 'warning', duration);
    },
    
    /**
     * Show an error notification
     * @param {string} message - The notification message
     * @param {number} [duration] - The duration to show the notification
     * @returns {string} The ID of the notification
     */
    error(message, duration) {
        return this.show(message, 'error', duration);
    },
    
    /**
     * Show an info notification
     * @param {string} message - The notification message
     * @param {number} [duration] - The duration to show the notification
     * @returns {string} The ID of the notification
     */
    info(message, duration) {
        return this.show(message, 'info', duration);
    },
    
    /**
     * Show a loading notification
     * @param {string} message - The notification message
     * @returns {string} The ID of the notification
     */
    loading(message = 'Loading...') {
        return this.show(message, 'info', 0, true);
    },
    
    /**
     * Update an existing notification
     * @param {string} id - The ID of the notification to update
     * @param {string} message - The new message
     * @param {string} [type] - The new type
     * @param {number} [duration] - The new duration
     * @returns {boolean} Whether the update was successful
     */
    update(id, message, type, duration) {
        const notification = this.activeNotifications.get(id);
        
        if (!notification) {
            return false;
        }
        
        // Update message
        const messageElement = notification.element.querySelector('.notification-message');
        if (messageElement && message) {
            messageElement.textContent = message;
        }
        
        // Update type
        if (type) {
            notification.element.className = `notification ${type}`;
            notification.options.type = type;
            
            // Update title
            const titleElement = notification.element.querySelector('.notification-title');
            if (titleElement) {
                switch (type) {
                    case 'success':
                        titleElement.textContent = 'Success';
                        break;
                    case 'warning':
                        titleElement.textContent = 'Warning';
                        break;
                    case 'error':
                        titleElement.textContent = 'Error';
                        break;
                    default:
                        titleElement.textContent = 'Information';
                }
            }
        }
        
        // Update duration
        if (duration !== undefined) {
            // Clear existing timer
            if (notification.timer) {
                clearTimeout(notification.timer);
                notification.timer = null;
            }
            
            // Set new timer if not permanent
            if (duration > 0) {
                notification.timer = setTimeout(() => this.hide(id), duration);
            }
            
            notification.options.duration = duration;
        }
        
        return true;
    },
    
    /**
     * Hide a specific notification
     * @param {string} id - The ID of the notification to hide
     * @returns {boolean} Whether the notification was hidden
     */
    hide(id) {
        const notification = this.activeNotifications.get(id);
        
        if (!notification) {
            return false;
        }
        
        // Clear timer if exists
        if (notification.timer) {
            clearTimeout(notification.timer);
        }
        
        // Animate out
        notification.element.style.opacity = '0';
        notification.element.style.transform = 'translateY(-20px)';
        
        // Remove after animation
        setTimeout(() => {
            if (notification.element.parentNode) {
                notification.element.parentNode.removeChild(notification.element);
            }
            this.activeNotifications.delete(id);
        }, 300);
        
        return true;
    },
    
    /**
     * Hide all notifications
     */
    hideAll() {
        this.activeNotifications.forEach((notification, id) => {
            this.hide(id);
        });
    },
    
    /**
     * Hide all loading notifications
     */
    hideLoading() {
        this.activeNotifications.forEach((notification, id) => {
            if (notification.options.isLoading) {
                this.hide(id);
            }
        });
    }
};

// Initialize notification component when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    notificationComponent.init();
});

// Make notification component available globally
window.notificationComponent = notificationComponent; 