/**
 * Challenge Component for ChallengeCraft AI
 */

const challengeComponent = {
    /**
     * Current active challenge
     */
    activeChallenge: null,
    
    /**
     * Challenge timer interval
     */
    timerInterval: null,
    
    /**
     * Time spent on current challenge (in seconds)
     */
    timeSpent: 0,
    
    /**
     * Hint counter for the current challenge
     */
    hintCounter: 0,
    
    /**
     * Initialize the challenge component
     */
    init() {
        // Get DOM elements
        this.elements = {
            challengeGrid: helpers.getElement('challengeGrid'),
            activeChallenge: helpers.getElement('active-challenge'),
            challengeTitle: helpers.getElement('challengeTitle'),
            challengeDifficulty: helpers.getElement('challengeDifficulty'),
            challengeCategory: helpers.getElement('challengeCategory'),
            challengeTimer: helpers.getElement('challengeTimer'),
            challengeDescription: helpers.getElement('challengeDescription'),
            challengeInput: helpers.getElement('challengeInput'),
            hintButton: helpers.getElement('hintButton'),
            submitSolution: helpers.getElement('submitSolution'),
            challengeFeedback: helpers.getElement('challengeFeedback'),
            challengeCanvas: helpers.getElement('challengeCanvas')
        };
        
        // Set up event listeners
        this.setupEventListeners();
        
        // Load challenges
        this.loadChallenges();
    },
    
    /**
     * Set up event listeners for challenge interactions
     */
    setupEventListeners() {
        // Start challenge button
        const startChallengeBtn = helpers.getElement('startChallenge');
        if (startChallengeBtn) {
            startChallengeBtn.addEventListener('click', () => this.generateNewChallenge());
        }
        
        // Hint button
        if (this.elements.hintButton) {
            this.elements.hintButton.addEventListener('click', () => this.showHint());
        }
        
        // Submit solution button
        if (this.elements.submitSolution) {
            this.elements.submitSolution.addEventListener('click', () => this.submitSolution());
        }
        
        // Filter listeners
        const difficultyFilter = helpers.getElement('difficultyFilter');
        const categoryFilter = helpers.getElement('categoryFilter');
        
        if (difficultyFilter) {
            difficultyFilter.addEventListener('change', () => this.filterChallenges());
        }
        
        if (categoryFilter) {
            categoryFilter.addEventListener('change', () => this.filterChallenges());
        }
    },
    
    /**
     * Load saved challenges from storage
     */
    loadChallenges() {
        const history = storage.getChallengeHistory();
        
        // Clear existing challenges
        if (this.elements.challengeGrid) {
            // Remove placeholders
            const placeholders = this.elements.challengeGrid.querySelectorAll('.placeholder');
            placeholders.forEach(placeholder => placeholder.remove());
            
            // Add challenge cards
            if (history.length > 0) {
                history.slice(0, 6).forEach(challenge => {
                    this.elements.challengeGrid.appendChild(this.createChallengeCard(challenge));
                });
            } else {
                // No challenges yet, add a message
                const noChallengesMsg = helpers.createElement('div', { className: 'no-challenges' }, 
                    `<p>No challenges yet! Click "Start a Challenge" to begin.</p>`
                );
                this.elements.challengeGrid.appendChild(noChallengesMsg);
            }
        }
        
        // Check for an active challenge
        const currentChallenge = storage.getCurrentChallenge();
        if (currentChallenge) {
            this.loadActiveChallenge(currentChallenge);
        }
    },
    
    /**
     * Generate a new challenge using the OpenRouter API
     */
    async generateNewChallenge() {
        // Show loading
        const loadingId = notificationComponent.show('Generating your challenge...', 'info', null, true);
        
        try {
            // Get user profile and preferences
            const userProfile = storage.getUserProfile();
            const stats = storage.getPerformanceStats();
            const preferences = storage.getPreferences();
            
            // Combine user data for API
            const userData = {
                ...userProfile,
                ...stats
            };
            
            // Generate challenge
            const challenge = await openRouter.generateChallenge(userData, {
                difficulty: preferences.difficulty === 'auto' ? null : preferences.difficulty,
                categories: userProfile.preferences.categories
            });
            
            // Save as current challenge
            storage.saveCurrentChallenge(challenge);
            
            // Make sure to hide loading indicator first
            notificationComponent.hideAll(); // Hide all notifications including loading
            
            // Display the challenge
            this.loadActiveChallenge(challenge);
            
            // Success notification after a short delay
            setTimeout(() => {
                notificationComponent.show(`Challenge "${challenge.title}" ready!`, 'success', 3000);
            }, 300);
            
        } catch (error) {
            console.error('Error generating challenge:', error);
            // Make sure to hide loading indicator
            notificationComponent.hideAll();
            notificationComponent.show('Failed to generate challenge. Please try again.', 'error');
        }
    },
    
    /**
     * Create a challenge card for display
     * @param {Object} challenge - The challenge data
     * @returns {HTMLElement} The challenge card element
     */
    createChallengeCard(challenge) {
        const card = document.createElement('div');
        card.className = 'challenge-card';
        card.setAttribute('data-id', challenge.id);
        
        // Add super-quick class for challenges under 10 minutes
        if (challenge.estimatedTime < 10) {
            card.classList.add('super-quick');
        }
        
        // Add quick challenge badge for daily or micro challenges
        if (challenge.isDaily || challenge.estimatedTime <= 15) {
            const quickBadge = document.createElement('div');
            quickBadge.className = 'quick-challenge-badge';
            quickBadge.textContent = challenge.isDaily ? 'Daily' : 'Quick';
            card.appendChild(quickBadge);
        }
        
        const cardContent = document.createElement('div');
        cardContent.className = 'challenge-content';
        
        // Challenge title
        const title = document.createElement('h3');
        title.textContent = challenge.title;
        cardContent.appendChild(title);
        
        // Challenge meta info
        const meta = document.createElement('div');
        meta.className = 'challenge-meta';
        
        // Difficulty badge
        const difficulty = document.createElement('span');
        difficulty.className = 'difficulty';
        difficulty.textContent = challenge.difficulty;
        meta.appendChild(difficulty);
        
        // Category badge
        const category = document.createElement('span');
        category.className = 'category';
        category.textContent = challenge.category;
        meta.appendChild(category);
        
        // Time estimation
        const time = document.createElement('span');
        time.className = 'timer';
        time.textContent = `${challenge.estimatedTime} min`;
        meta.appendChild(time);
        
        cardContent.appendChild(meta);
        
        // Challenge description
        const description = document.createElement('p');
        description.className = 'challenge-description';
        description.textContent = challenge.description;
        cardContent.appendChild(description);
        
        // Time indicator for quick challenges
        if (challenge.estimatedTime <= 15) {
            const timeIndicator = document.createElement('div');
            timeIndicator.className = 'challenge-time-indicator';
            
            const timeIcon = document.createElement('span');
            timeIcon.className = 'time-icon';
            timeIcon.textContent = '⏱️';
            
            const timeText = document.createElement('span');
            timeText.textContent = `Complete in ${challenge.estimatedTime} min`;
            
            timeIndicator.appendChild(timeIcon);
            timeIndicator.appendChild(timeText);
            cardContent.appendChild(timeIndicator);
        }
        
        // Start button
        const startButton = document.createElement('button');
        startButton.className = 'btn btn-primary';
        startButton.textContent = 'Start Challenge';
        startButton.addEventListener('click', () => this.loadActiveChallenge(challenge));
        cardContent.appendChild(startButton);
        
        card.appendChild(cardContent);
        return card;
    },
    
    /**
     * Load an active challenge into the UI
     * @param {Object} challenge - The challenge to display
     */
    loadActiveChallenge(challenge) {
        // Store as active challenge
        this.activeChallenge = challenge;
        
        // Clear any existing timer
        this.clearTimer();
        this.timeSpent = 0;
        this.hintCounter = 0;
        
        // First fade out the section if it's visible
        if (!this.elements.activeChallenge.classList.contains('hidden')) {
            this.elements.activeChallenge.style.opacity = '0';
            this.elements.activeChallenge.style.transform = 'translateY(10px)';
        }
        
        // Update UI elements after a short delay
        setTimeout(() => {
            this.elements.challengeTitle.textContent = challenge.title;
            this.elements.challengeDifficulty.textContent = challenge.difficulty;
            this.elements.challengeCategory.textContent = challenge.category;
            this.elements.challengeTimer.textContent = '00:00';
            
            // Format description with instructions and criteria
            let descriptionHTML = `
                <div class="challenge-description-text">${challenge.description}</div>
                <div class="challenge-instructions">
                    <h4>Instructions:</h4>
                    <div>${challenge.instructions}</div>
                </div>
                <div class="challenge-criteria">
                    <h4>Success Criteria:</h4>
                    <ul>
                        ${challenge.criteria.map(criterion => `<li>${criterion}</li>`).join('')}
                    </ul>
                </div>
            `;
            
            this.elements.challengeDescription.innerHTML = descriptionHTML;
            
            // Clear input and feedback
            this.elements.challengeInput.value = '';
            this.elements.challengeFeedback.innerHTML = '';
            helpers.hideElement(this.elements.challengeFeedback);
            
            // Show challenge section with fade-in effect
            this.elements.activeChallenge.classList.remove('hidden');
            this.elements.activeChallenge.style.opacity = '0';
            this.elements.activeChallenge.style.transform = 'translateY(20px)';
            
            // Add enhanced animation class
            this.elements.activeChallenge.classList.add('highlight-section');
            
            // Fade in with transition
            setTimeout(() => {
                this.elements.activeChallenge.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
                this.elements.activeChallenge.style.opacity = '1';
                this.elements.activeChallenge.style.transform = 'translateY(0)';
                
                // Scroll to the active challenge
                setTimeout(() => {
                    const activeChallenge = this.elements.activeChallenge;
                    if (activeChallenge) {
                        // Get the element's position relative to the viewport
                        const rect = activeChallenge.getBoundingClientRect();
                        // Scroll to the element with a small offset from the top
                        window.scrollTo({
                            top: window.pageYOffset + rect.top - 100,
                            behavior: 'smooth'
                        });
                    }
                    
                    // Remove highlight effect after animation completes
                    setTimeout(() => {
                        this.elements.activeChallenge.classList.remove('highlight-section');
                    }, 1500);
                    
                }, 200);
            }, 50);
            
            // Start timer
            this.startTimer();
            
            // Initialize canvas visualization
            this.initCanvas();
        }, 100);
    },
    
    /**
     * Start the challenge timer
     */
    startTimer() {
        this.timerInterval = setInterval(() => {
            this.timeSpent++;
            this.elements.challengeTimer.textContent = helpers.formatTime(this.timeSpent);
        }, 1000);
    },
    
    /**
     * Clear the challenge timer
     */
    clearTimer() {
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
            this.timerInterval = null;
        }
    },
    
    /**
     * Initialize canvas visualization
     */
    initCanvas() {
        const canvas = this.elements.challengeCanvas;
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Set canvas size
        canvas.width = canvas.clientWidth;
        canvas.height = canvas.clientHeight;
        
        // Draw a simple visualization based on the challenge
        this.drawChallengeVisualization(ctx, canvas.width, canvas.height);
    },
    
    /**
     * Draw a visualization on canvas based on the active challenge
     * @param {CanvasRenderingContext2D} ctx - The canvas context
     * @param {number} width - Canvas width
     * @param {number} height - Canvas height
     */
    drawChallengeVisualization(ctx, width, height) {
        if (!this.activeChallenge) return;
        
        const difficulty = this.activeChallenge.difficulty;
        
        // Difficulty colors
        const colors = {
            beginner: '#4caf50',
            intermediate: '#2196f3',
            advanced: '#ff9800',
            expert: '#f44336'
        };
        
        const color = colors[difficulty] || colors.beginner;
        
        // Draw a pattern based on difficulty
        ctx.fillStyle = '#f5f5f5';
        ctx.fillRect(0, 0, width, height);
        
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        
        // Draw a different pattern based on category
        switch (this.activeChallenge.category) {
            case 'coding':
                this.drawCodePattern(ctx, width, height, color);
                break;
            case 'problem-solving':
                this.drawProblemSolvingPattern(ctx, width, height, color);
                break;
            case 'creativity':
                this.drawCreativityPattern(ctx, width, height, color);
                break;
            case 'design':
                this.drawDesignPattern(ctx, width, height, color);
                break;
            default:
                this.drawDefaultPattern(ctx, width, height, color);
        }
        
        // Add title
        ctx.fillStyle = '#333';
        ctx.font = 'bold 16px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(this.activeChallenge.title, width / 2, 30);
    },
    
    /**
     * Draw a code-themed pattern on canvas
     * @param {CanvasRenderingContext2D} ctx - The canvas context
     * @param {number} width - Canvas width
     * @param {number} height - Canvas height
     * @param {string} color - The color to use
     */
    drawCodePattern(ctx, width, height, color) {
        // Draw a pattern that resembles code structure
        const lineCount = 12;
        const lineSpacing = height / (lineCount + 2);
        
        for (let i = 0; i < lineCount; i++) {
            const y = lineSpacing * (i + 1);
            const lineWidth = Math.random() * (width * 0.6) + (width * 0.2);
            
            ctx.beginPath();
            ctx.moveTo(width * 0.1, y);
            ctx.lineTo(lineWidth, y);
            ctx.stroke();
            
            // Add some "indentation"
            if (i % 3 === 1) {
                ctx.beginPath();
                ctx.moveTo(width * 0.15, y + lineSpacing);
                ctx.lineTo(width * 0.15 + Math.random() * (width * 0.4), y + lineSpacing);
                ctx.stroke();
                i++;
            }
        }
        
        // Add some "brackets"
        ctx.beginPath();
        ctx.moveTo(width * 0.15, lineSpacing * 2);
        ctx.lineTo(width * 0.12, lineSpacing * 2);
        ctx.lineTo(width * 0.12, height - lineSpacing * 2);
        ctx.lineTo(width * 0.15, height - lineSpacing * 2);
        ctx.stroke();
    },
    
    /**
     * Draw a problem-solving pattern on canvas
     * @param {CanvasRenderingContext2D} ctx - The canvas context
     * @param {number} width - Canvas width
     * @param {number} height - Canvas height
     * @param {string} color - The color to use
     */
    drawProblemSolvingPattern(ctx, width, height, color) {
        // Draw a pattern that resembles a puzzle or maze
        const gridSize = 7;
        const cellSize = Math.min(width, height) / (gridSize + 2);
        const startX = width / 2 - (cellSize * gridSize) / 2;
        const startY = height / 2 - (cellSize * gridSize) / 2;
        
        // Draw a maze-like pattern
        for (let i = 0; i < gridSize; i++) {
            for (let j = 0; j < gridSize; j++) {
                const x = startX + i * cellSize;
                const y = startY + j * cellSize;
                
                // Randomly decide which walls to draw
                const drawTop = Math.random() > 0.3;
                const drawRight = Math.random() > 0.3;
                
                if (drawTop) {
                    ctx.beginPath();
                    ctx.moveTo(x, y);
                    ctx.lineTo(x + cellSize, y);
                    ctx.stroke();
                }
                
                if (drawRight) {
                    ctx.beginPath();
                    ctx.moveTo(x + cellSize, y);
                    ctx.lineTo(x + cellSize, y + cellSize);
                    ctx.stroke();
                }
            }
        }
    },
    
    /**
     * Draw a creativity pattern on canvas
     * @param {CanvasRenderingContext2D} ctx - The canvas context
     * @param {number} width - Canvas width
     * @param {number} height - Canvas height
     * @param {string} color - The color to use
     */
    drawCreativityPattern(ctx, width, height, color) {
        // Draw abstract shapes for creativity
        for (let i = 0; i < 15; i++) {
            const x = Math.random() * width;
            const y = Math.random() * height;
            const size = Math.random() * 50 + 10;
            
            ctx.beginPath();
            
            // Vary shape types
            const shapeType = Math.floor(Math.random() * 3);
            
            switch (shapeType) {
                case 0: // Circle
                    ctx.arc(x, y, size / 2, 0, Math.PI * 2);
                    break;
                case 1: // Square
                    ctx.rect(x - size / 2, y - size / 2, size, size);
                    break;
                case 2: // Triangle
                    ctx.moveTo(x, y - size / 2);
                    ctx.lineTo(x + size / 2, y + size / 2);
                    ctx.lineTo(x - size / 2, y + size / 2);
                    ctx.closePath();
                    break;
            }
            
            ctx.globalAlpha = 0.2;
            ctx.fillStyle = color;
            ctx.fill();
            ctx.globalAlpha = 1;
            ctx.stroke();
        }
    },
    
    /**
     * Draw a design pattern on canvas
     * @param {CanvasRenderingContext2D} ctx - The canvas context
     * @param {number} width - Canvas width
     * @param {number} height - Canvas height
     * @param {string} color - The color to use
     */
    drawDesignPattern(ctx, width, height, color) {
        // Create a grid layout design
        const gridSize = 4;
        const margin = 20;
        const cellWidth = (width - margin * 2) / gridSize;
        const cellHeight = (height - margin * 2) / gridSize;
        
        for (let i = 0; i < gridSize; i++) {
            for (let j = 0; j < gridSize; j++) {
                const x = margin + i * cellWidth;
                const y = margin + j * cellHeight;
                
                // Create a 2x2 alternating grid pattern
                if ((i + j) % 2 === 0) {
                    ctx.fillStyle = color;
                    ctx.globalAlpha = 0.1;
                    ctx.fillRect(x, y, cellWidth, cellHeight);
                    ctx.globalAlpha = 1;
                }
                
                // Draw cell border
                ctx.strokeRect(x, y, cellWidth, cellHeight);
            }
        }
        
        // Add design elements
        ctx.beginPath();
        ctx.moveTo(margin, margin);
        ctx.lineTo(width - margin, height - margin);
        ctx.stroke();
        
        ctx.beginPath();
        ctx.moveTo(width - margin, margin);
        ctx.lineTo(margin, height - margin);
        ctx.stroke();
    },
    
    /**
     * Draw default pattern on canvas
     * @param {CanvasRenderingContext2D} ctx - The canvas context
     * @param {number} width - Canvas width
     * @param {number} height - Canvas height
     * @param {string} color - The color to use
     */
    drawDefaultPattern(ctx, width, height, color) {
        // Draw concentric circles
        const maxRadius = Math.min(width, height) / 2 - 20;
        const centerX = width / 2;
        const centerY = height / 2;
        
        for (let radius = maxRadius; radius > 0; radius -= 20) {
            ctx.beginPath();
            ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
            ctx.stroke();
        }
        
        // Draw lines from center
        for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 8) {
            const x = centerX + Math.cos(angle) * maxRadius;
            const y = centerY + Math.sin(angle) * maxRadius;
            
            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.lineTo(x, y);
            ctx.stroke();
        }
    },
    
    /**
     * Show a hint for the current challenge
     */
    showHint() {
        if (!this.activeChallenge || !this.activeChallenge.hints) {
            notificationComponent.show('No hints available for this challenge', 'info');
            return;
        }
        
        const hint = openRouter.getHint(this.activeChallenge, this.hintCounter);
        
        // Create modal with the hint
        modalComponent.show({
            title: 'Hint',
            content: `<div class="hint-content">${hint}</div>`,
            buttons: [
                {
                    text: 'Close',
                    action: 'close',
                    className: 'btn-secondary'
                }
            ]
        });
        
        // Increment hint counter for next hint
        this.hintCounter = (this.hintCounter + 1) % this.activeChallenge.hints.length;
    },
    
    /**
     * Submit solution for evaluation
     */
    async submitSolution() {
        if (!this.activeChallenge) {
            notificationComponent.show('No active challenge to submit', 'error');
            return;
        }
        
        const solution = this.elements.challengeInput.value.trim();
        
        if (helpers.isEmpty(solution)) {
            notificationComponent.show('Please enter your solution before submitting', 'warning');
            helpers.addClass(this.elements.challengeInput, 'shake', 800);
            return;
        }
        
        // Show loading notification
        const loadingId = notificationComponent.show('Evaluating your solution...', 'info', null, true);
        
        try {
            // Stop timer
            this.clearTimer();
            
            // Evaluate solution
            const evaluation = await openRouter.evaluateSolution(this.activeChallenge, solution);
            
            // Clear all notifications first
            notificationComponent.hideAll();
            
            // Display feedback
            this.showFeedback(evaluation);
            
            // Update stats
            this.updateStats(evaluation.success);
            
            // Add to history if not already there
            this.addToHistory(evaluation);
            
            // Show brief success notification
            if (evaluation.success) {
                setTimeout(() => {
                    notificationComponent.show('Challenge completed!', 'success', 2000);
                }, 300);
            } else {
                setTimeout(() => {
                    notificationComponent.show('Challenge attempted. Try again!', 'info', 2000);
                }, 300);
            }
            
        } catch (error) {
            console.error('Error evaluating solution:', error);
            // Clear all notifications
            notificationComponent.hideAll();
            notificationComponent.show('Failed to evaluate solution. Please try again.', 'error');
            
            // Restart timer
            this.startTimer();
        }
    },
    
    /**
     * Show feedback for the submitted solution
     * @param {Object} evaluation - The evaluation results
     */
    showFeedback(evaluation) {
        // Create feedback content
        let feedbackHTML = `
            <div class="feedback-header ${evaluation.success ? 'success' : 'failure'}">
                <div class="feedback-status">
                    ${evaluation.success ? 
                        '<div class="success-checkmark">✓</div>' : 
                        '<div class="failure-x">✗</div>'}
                </div>
                <div class="feedback-title">
                    <h4>${evaluation.success ? 'Challenge Completed!' : 'Not Quite Right'}</h4>
                    <div class="feedback-score">Score: ${evaluation.score}/100</div>
                </div>
            </div>
            <div class="feedback-content">
                <h5>Feedback:</h5>
                <div class="feedback-text">${evaluation.feedback}</div>
                
                ${evaluation.improvedSolution ? `
                <h5>Improved Solution:</h5>
                <div class="improved-solution">${evaluation.improvedSolution}</div>
                ` : ''}
                
                ${evaluation.nextSteps && evaluation.nextSteps.length > 0 ? `
                <h5>Next Steps:</h5>
                <ul class="next-steps">
                    ${evaluation.nextSteps.map(step => `<li>${step}</li>`).join('')}
                </ul>
                ` : ''}
            </div>
            <div class="feedback-actions">
                <button id="newChallengeBtn" class="btn btn-primary">New Challenge</button>
                <button id="tryAgainBtn" class="btn btn-secondary">Try Again</button>
            </div>
        `;
        
        // Update feedback element
        this.elements.challengeFeedback.innerHTML = feedbackHTML;
        this.elements.challengeFeedback.style.opacity = '0';
        this.elements.challengeFeedback.style.transform = 'translateY(20px)';
        helpers.showElement(this.elements.challengeFeedback);
        
        // Fade in feedback with animation
        setTimeout(() => {
            this.elements.challengeFeedback.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
            this.elements.challengeFeedback.style.opacity = '1';
            this.elements.challengeFeedback.style.transform = 'translateY(0)';
            
            // Scroll to feedback
            helpers.scrollToElement(this.elements.challengeFeedback, 80);
        }, 50);
        
        // Add event listeners to feedback buttons
        const newChallengeBtn = document.getElementById('newChallengeBtn');
        const tryAgainBtn = document.getElementById('tryAgainBtn');
        
        if (newChallengeBtn) {
            newChallengeBtn.addEventListener('click', () => {
                // Clear current feedback first
                helpers.hideElement(this.elements.challengeFeedback);
                this.elements.challengeFeedback.innerHTML = '';
                // Clear input
                this.elements.challengeInput.value = '';
                // Generate new challenge
                this.generateNewChallenge();
            });
        }
        
        if (tryAgainBtn) {
            tryAgainBtn.addEventListener('click', () => {
                // Hide feedback but keep input for editing
                this.elements.challengeFeedback.style.opacity = '0';
                this.elements.challengeFeedback.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    helpers.hideElement(this.elements.challengeFeedback);
                    this.elements.challengeFeedback.innerHTML = '';
                    // Focus back on input
                    this.elements.challengeInput.focus();
                    // Restart timer
                    this.startTimer();
                }, 300);
            });
        }
    },
    
    /**
     * Update user stats after challenge completion
     * @param {boolean} success - Whether the challenge was successful
     */
    updateStats(success) {
        const stats = storage.getPerformanceStats();
        
        // Update stats
        stats.completedChallenges += 1;
        if (success) {
            stats.successfulChallenges += 1;
        }
        
        stats.totalTimeSpent += this.timeSpent;
        
        // Update streak
        storage.updateStreak(success);
        
        // Save updated stats
        storage.updatePerformanceStats(stats);
        
        // Update UI if stats section is visible
        const completedChallenges = helpers.getElement('completedChallenges');
        const successRate = helpers.getElement('successRate');
        const currentStreak = helpers.getElement('currentStreak');
        
        if (completedChallenges) {
            completedChallenges.textContent = stats.completedChallenges;
        }
        
        if (successRate) {
            const rate = stats.completedChallenges > 0 ? 
                Math.round((stats.successfulChallenges / stats.completedChallenges) * 100) : 0;
            successRate.textContent = `${rate}%`;
        }
        
        if (currentStreak) {
            currentStreak.textContent = stats.streak;
        }
    },
    
    /**
     * Add the completed challenge to history
     * @param {Object} evaluation - The evaluation results
     */
    addToHistory(evaluation) {
        // Create history entry
        const historyEntry = {
            ...this.activeChallenge,
            completed: true,
            success: evaluation.success,
            score: evaluation.score,
            timeSpent: this.timeSpent,
            timestamp: new Date().toISOString()
        };
        
        // Add to history
        storage.addChallengeToHistory(historyEntry);
        
        // Clear current challenge
        storage.clearCurrentChallenge();
        this.activeChallenge = null;
        
        // Update activity list if visible
        this.updateActivityList(historyEntry);
    },
    
    /**
     * Update the activity list with a new challenge
     * @param {Object} challenge - The challenge to add
     */
    updateActivityList(challenge) {
        const activityList = helpers.getElement('activityList');
        if (!activityList) return;
        
        // Create activity item
        const activityItem = helpers.createElement('li', { className: 'activity-item fade-in' });
        
        // Create icon
        const iconClass = challenge.success ? 'success' : 'failure';
        const iconSymbol = challenge.success ? '✓' : '✗';
        const activityIcon = helpers.createElement('div', { className: `activity-icon ${iconClass}` }, iconSymbol);
        
        // Create content
        const activityContent = helpers.createElement('div', { className: 'activity-content' });
        
        // Add title
        const activityTitle = helpers.createElement('div', { className: 'activity-title' }, `
            ${challenge.title} - ${challenge.success ? 'Completed' : 'Attempted'}
        `);
        
        // Add time
        const activityTime = helpers.createElement('div', { className: 'activity-time' }, 
            helpers.formatDate(challenge.timestamp, true)
        );
        
        // Assemble activity item
        activityContent.appendChild(activityTitle);
        activityContent.appendChild(activityTime);
        activityItem.appendChild(activityIcon);
        activityItem.appendChild(activityContent);
        
        // Add to the top of the list
        if (activityList.firstChild) {
            activityList.insertBefore(activityItem, activityList.firstChild);
        } else {
            activityList.appendChild(activityItem);
        }
    },
    
    /**
     * Filter challenges based on selected filters
     */
    filterChallenges() {
        const difficultyFilter = helpers.getElement('difficultyFilter');
        const categoryFilter = helpers.getElement('categoryFilter');
        
        if (!difficultyFilter || !categoryFilter || !this.elements.challengeGrid) {
            return;
        }
        
        const difficulty = difficultyFilter.value;
        const category = categoryFilter.value;
        
        // Get all challenge cards
        const cards = this.elements.challengeGrid.querySelectorAll('.challenge-card:not(.placeholder)');
        
        cards.forEach(card => {
            const cardDifficulty = card.querySelector('.difficulty')?.textContent;
            const cardCategory = card.querySelector('.category')?.textContent;
            
            const difficultyMatch = difficulty === 'all' || cardDifficulty === difficulty;
            const categoryMatch = category === 'all' || cardCategory === category;
            
            if (difficultyMatch && categoryMatch) {
                card.style.display = '';
            } else {
                card.style.display = 'none';
            }
        });
    }
};

// Initialize challenge component when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    challengeComponent.init();
});

// Make challenge component available globally
window.challengeComponent = challengeComponent; 