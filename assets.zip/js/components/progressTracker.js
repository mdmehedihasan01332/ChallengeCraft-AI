/**
 * Progress Tracker Component for ChallengeCraft AI
 */

const progressTracker = {
    /**
     * Canvas element for chart
     */
    chartCanvas: null,
    
    /**
     * Chart instance
     */
    chart: null,
    
    /**
     * Initialize the progress tracker component
     */
    init() {
        // Get canvas element
        this.chartCanvas = document.getElementById('progressChart');
        
        // Initialize chart if canvas exists
        if (this.chartCanvas) {
            this.initChart();
        }
        
        // Update stats display
        this.updateStatsDisplay();
        
        // Update activity list
        this.updateActivityList();
    },
    
    /**
     * Initialize the progress chart
     */
    initChart() {
        const ctx = this.chartCanvas.getContext('2d');
        
        // Get performance data
        const performanceData = this.getPerformanceData();
        
        // Set up chart data
        const data = {
            labels: performanceData.labels,
            datasets: [
                {
                    label: 'Score',
                    data: performanceData.scores,
                    backgroundColor: 'rgba(74, 107, 255, 0.2)',
                    borderColor: 'rgba(74, 107, 255, 1)',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: true
                },
                {
                    label: 'Time Spent (min)',
                    data: performanceData.times,
                    backgroundColor: 'rgba(69, 202, 255, 0.2)',
                    borderColor: 'rgba(69, 202, 255, 1)',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: true,
                    hidden: true
                }
            ]
        };
        
        // Draw the chart
        this.drawChart(ctx, data);
    },
    
    /**
     * Get performance data for the chart
     * @returns {Object} The formatted performance data
     */
    getPerformanceData() {
        // Get challenge history
        const history = storage.getChallengeHistory();
        
        // Return empty data if no history
        if (!history || history.length === 0) {
            return {
                labels: [],
                scores: [],
                times: []
            };
        }
        
        // Sort by date (oldest to newest)
        const sortedHistory = [...history].sort((a, b) => {
            return new Date(a.timestamp) - new Date(b.timestamp);
        });
        
        // Get up to last 10 challenges
        const recentHistory = sortedHistory.slice(-10);
        
        // Extract data
        const labels = recentHistory.map(challenge => {
            const date = new Date(challenge.timestamp);
            return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        });
        
        const scores = recentHistory.map(challenge => challenge.score || 0);
        const times = recentHistory.map(challenge => Math.round(challenge.timeSpent / 60)); // Convert to minutes
        
        return {
            labels,
            scores,
            times
        };
    },
    
    /**
     * Draw the progress chart
     * @param {CanvasRenderingContext2D} ctx - The canvas context
     * @param {Object} data - The chart data
     */
    drawChart(ctx, data) {
        // Simple line chart without external libraries
        
        if (data.labels.length === 0) {
            // Draw "No Data" message
            ctx.font = '20px Inter, sans-serif';
            ctx.fillStyle = '#888888';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('No data available. Complete challenges to see your progress.', this.chartCanvas.width / 2, this.chartCanvas.height / 2);
            return;
        }
        
        const width = this.chartCanvas.width;
        const height = this.chartCanvas.height;
        const padding = 40;
        
        // Clear canvas
        ctx.clearRect(0, 0, width, height);
        
        // Draw axes
        ctx.beginPath();
        ctx.strokeStyle = '#dddddd';
        ctx.lineWidth = 1;
        
        // Draw grid lines
        const gridCount = 5;
        for (let i = 0; i <= gridCount; i++) {
            const y = padding + (height - padding * 2) * (1 - i / gridCount);
            ctx.moveTo(padding, y);
            ctx.lineTo(width - padding, y);
            
            // Add score label
            const scoreValue = i * 20; // 0 to 100 by 20s
            ctx.fillStyle = '#888888';
            ctx.font = '12px Inter, sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText(scoreValue.toString(), padding - 5, y + 4);
        }
        ctx.stroke();
        
        // Draw x-axis labels
        const labelStep = Math.max(1, Math.floor(data.labels.length / 10));
        for (let i = 0; i < data.labels.length; i += labelStep) {
            const x = padding + (width - padding * 2) * (i / (data.labels.length - 1 || 1));
            ctx.fillStyle = '#888888';
            ctx.font = '12px Inter, sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(data.labels[i], x, height - padding + 15);
        }
        
        // Draw line for scores
        const scoreData = data.datasets[0].data;
        if (scoreData.length > 0) {
            ctx.beginPath();
            ctx.strokeStyle = data.datasets[0].borderColor;
            ctx.lineWidth = data.datasets[0].borderWidth;
            
            // Calculate area path for fill
            const areaPath = new Path2D();
            
            for (let i = 0; i < scoreData.length; i++) {
                const x = padding + (width - padding * 2) * (i / (scoreData.length - 1 || 1));
                const y = padding + (height - padding * 2) * (1 - scoreData[i] / 100);
                
                if (i === 0) {
                    ctx.moveTo(x, y);
                    areaPath.moveTo(x, y);
                } else {
                    ctx.lineTo(x, y);
                    areaPath.lineTo(x, y);
                }
                
                // Draw point
                ctx.fillStyle = data.datasets[0].borderColor;
                ctx.beginPath();
                ctx.arc(x, y, 4, 0, Math.PI * 2);
                ctx.fill();
                
                // Add score value above point
                ctx.fillStyle = '#666666';
                ctx.font = '12px Inter, sans-serif';
                ctx.textAlign = 'center';
                ctx.fillText(scoreData[i].toString(), x, y - 10);
            }
            
            // Close the area path for fill
            const lastX = padding + (width - padding * 2);
            const baseY = padding + (height - padding * 2);
            areaPath.lineTo(lastX, baseY);
            areaPath.lineTo(padding, baseY);
            areaPath.closePath();
            
            // Fill the area
            ctx.fillStyle = data.datasets[0].backgroundColor;
            ctx.fill(areaPath);
            
            // Stroke the line
            ctx.stroke();
        }
        
        // Add legend
        ctx.fillStyle = data.datasets[0].borderColor;
        ctx.fillRect(width - padding - 100, padding, 12, 12);
        ctx.fillStyle = '#333333';
        ctx.font = '14px Inter, sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText('Score', width - padding - 80, padding + 10);
    },
    
    /**
     * Update the stats display
     */
    updateStatsDisplay() {
        // Get performance stats
        const stats = storage.getPerformanceStats();
        
        // Update completed challenges count
        const completedChallenges = document.getElementById('completedChallenges');
        if (completedChallenges) {
            completedChallenges.textContent = stats.completedChallenges;
        }
        
        // Update success rate
        const successRate = document.getElementById('successRate');
        if (successRate) {
            const rate = stats.completedChallenges > 0 ? 
                Math.round((stats.successfulChallenges / stats.completedChallenges) * 100) : 0;
            successRate.textContent = `${rate}%`;
        }
        
        // Update current streak
        const currentStreak = document.getElementById('currentStreak');
        if (currentStreak) {
            currentStreak.textContent = stats.streak;
        }
    },
    
    /**
     * Update the activity list
     */
    updateActivityList() {
        const activityList = document.getElementById('activityList');
        if (!activityList) return;
        
        // Clear existing items
        activityList.innerHTML = '';
        
        // Get challenge history
        const history = storage.getChallengeHistory();
        
        if (!history || history.length === 0) {
            // No activity yet
            const noActivity = document.createElement('li');
            noActivity.className = 'no-activity';
            noActivity.textContent = 'No activity yet. Complete challenges to see your progress.';
            activityList.appendChild(noActivity);
            return;
        }
        
        // Display last 10 activities
        history.slice(0, 10).forEach(challenge => {
            const activityItem = document.createElement('li');
            activityItem.className = 'activity-item';
            
            // Create icon
            const iconClass = challenge.success ? 'success' : 'failure';
            const iconSymbol = challenge.success ? '✓' : '✗';
            
            const activityIcon = document.createElement('div');
            activityIcon.className = `activity-icon ${iconClass}`;
            activityIcon.textContent = iconSymbol;
            
            // Create content
            const activityContent = document.createElement('div');
            activityContent.className = 'activity-content';
            
            // Add title
            const activityTitle = document.createElement('div');
            activityTitle.className = 'activity-title';
            activityTitle.textContent = `${challenge.title} - ${challenge.success ? 'Completed' : 'Attempted'}`;
            
            // Add time
            const activityTime = document.createElement('div');
            activityTime.className = 'activity-time';
            activityTime.textContent = helpers.formatDate(challenge.timestamp, true);
            
            // Assemble activity item
            activityContent.appendChild(activityTitle);
            activityContent.appendChild(activityTime);
            activityItem.appendChild(activityIcon);
            activityItem.appendChild(activityContent);
            
            // Add to list
            activityList.appendChild(activityItem);
        });
    },
    
    /**
     * Get performance insights based on user stats
     * @returns {Object} Insights about user performance
     */
    getPerformanceInsights() {
        // Get stats and history
        const stats = storage.getPerformanceStats();
        const history = storage.getChallengeHistory();
        
        // Initialize insights
        const insights = {
            strengthCategory: null,
            weaknessCategory: null,
            averageScore: 0,
            averageTime: 0,
            improvement: false,
            suggestions: []
        };
        
        if (!history || history.length === 0) {
            insights.suggestions.push("Start completing challenges to see performance insights.");
            return insights;
        }
        
        // Calculate average score and time
        let totalScore = 0;
        let totalTime = 0;
        history.forEach(challenge => {
            totalScore += challenge.score || 0;
            totalTime += challenge.timeSpent || 0;
        });
        
        insights.averageScore = Math.round(totalScore / history.length);
        insights.averageTime = Math.round(totalTime / history.length / 60); // In minutes
        
        // Analyze performance by category
        const categoryPerformance = {};
        
        history.forEach(challenge => {
            if (!challenge.category) return;
            
            if (!categoryPerformance[challenge.category]) {
                categoryPerformance[challenge.category] = {
                    total: 0,
                    success: 0,
                    scores: [],
                    times: []
                };
            }
            
            const category = categoryPerformance[challenge.category];
            category.total++;
            if (challenge.success) {
                category.success++;
            }
            category.scores.push(challenge.score || 0);
            category.times.push(challenge.timeSpent || 0);
        });
        
        // Find strengths and weaknesses
        let bestCategory = null;
        let worstCategory = null;
        let bestScore = -1;
        let worstScore = 101;
        
        Object.entries(categoryPerformance).forEach(([category, data]) => {
            if (data.total < 2) return; // Need at least 2 challenges for meaningful data
            
            // Calculate average score for this category
            const avgScore = data.scores.reduce((a, b) => a + b, 0) / data.scores.length;
            
            if (avgScore > bestScore) {
                bestScore = avgScore;
                bestCategory = category;
            }
            
            if (avgScore < worstScore) {
                worstScore = avgScore;
                worstCategory = category;
            }
        });
        
        insights.strengthCategory = bestCategory;
        insights.weaknessCategory = worstCategory;
        
        // Check for improvement
        if (history.length >= 3) {
            const recentChallenges = [...history].sort((a, b) => {
                return new Date(b.timestamp) - new Date(a.timestamp);
            }).slice(0, 3);
            
            const oldChallenges = [...history].sort((a, b) => {
                return new Date(a.timestamp) - new Date(b.timestamp);
            }).slice(0, 3);
            
            const recentAvgScore = recentChallenges.reduce((sum, challenge) => sum + (challenge.score || 0), 0) / recentChallenges.length;
            const oldAvgScore = oldChallenges.reduce((sum, challenge) => sum + (challenge.score || 0), 0) / oldChallenges.length;
            
            insights.improvement = recentAvgScore > oldAvgScore;
        }
        
        // Generate suggestions
        if (insights.weaknessCategory) {
            insights.suggestions.push(`Focus on improving your ${insights.weaknessCategory} skills.`);
        }
        
        if (insights.averageScore < 60) {
            insights.suggestions.push("Try using hints more effectively when stuck on challenges.");
        }
        
        if (insights.averageTime > 30) {
            insights.suggestions.push("Work on improving your speed by practicing similar challenges.");
        }
        
        if (stats.streak < 2) {
            insights.suggestions.push("Maintain a regular practice schedule to build a streak.");
        }
        
        return insights;
    },
    
    /**
     * Show performance insights in a modal
     */
    showInsights() {
        const insights = this.getPerformanceInsights();
        
        let content = `
            <div class="insights-container">
                <div class="insights-summary">
                    <div class="insight-item">
                        <div class="insight-label">Average Score</div>
                        <div class="insight-value">${insights.averageScore}%</div>
                    </div>
                    <div class="insight-item">
                        <div class="insight-label">Average Time</div>
                        <div class="insight-value">${insights.averageTime} min</div>
                    </div>
                </div>
                
                ${insights.strengthCategory ? `
                <div class="insight-strength">
                    <h4>Your Strength</h4>
                    <p>You perform best in <strong>${insights.strengthCategory}</strong> challenges.</p>
                </div>
                ` : ''}
                
                ${insights.weaknessCategory ? `
                <div class="insight-weakness">
                    <h4>Area for Improvement</h4>
                    <p>You may want to focus more on <strong>${insights.weaknessCategory}</strong> challenges.</p>
                </div>
                ` : ''}
                
                ${insights.improvement ? `
                <div class="insight-improvement">
                    <h4>Progress</h4>
                    <p>You're showing improvement in your recent challenges! Keep it up!</p>
                </div>
                ` : ''}
                
                ${insights.suggestions.length > 0 ? `
                <div class="insight-suggestions">
                    <h4>Suggestions</h4>
                    <ul>
                        ${insights.suggestions.map(suggestion => `<li>${suggestion}</li>`).join('')}
                    </ul>
                </div>
                ` : ''}
            </div>
        `;
        
        modalComponent.show({
            title: 'Performance Insights',
            content: content,
            size: 'medium'
        });
    }
};

// Initialize progress tracker when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    progressTracker.init();
});

// Make progress tracker available globally
window.progressTracker = progressTracker; 