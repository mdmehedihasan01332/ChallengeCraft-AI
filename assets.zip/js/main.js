/**
 * Main JavaScript file for ChallengeCraft AI
 */

// Main application object
const app = {
    /**
     * Flag to indicate if the app is initialized
     */
    initialized: false,
    
    /**
     * User progression data
     */
    progression: {
        level: 1,
        xp: 0,
        totalXP: 0,
        nextLevelXP: 100,
        streakDays: 0,
        lastLoginDate: null,
        badges: [],
        achievements: [],
        weeklyGoal: 5, // Challenges per week
        weeklyProgress: 0,
    },
    
    /**
     * Initialize the application
     */
    init() {
        if (this.initialized) return;
        
        // Initialize services
        this.setupServices();
        
        // Set up global event listeners
        this.setupEventListeners();
        
        // Handle service worker for PWA support
        this.setupServiceWorker();
        
        // Add resize handler for responsive canvas
        this.setupResizeHandlers();
        
        // Handle theme preference
        this.setupThemePreference();
        
        // Initialize progression system
        this.initProgressionSystem();
        
        // Check for daily challenge
        this.checkDailyChallenge();
        
        // Check for login streak
        this.checkLoginStreak();
        
        // Initialize leaderboard
        this.initLeaderboard();
        
        // Hide loading indicator
        this.hideLoading();
        
        // Show welcome back notification if returning user
        this.showWelcomeBackMessage();
        
        this.initialized = true;
        
        console.log('ChallengeCraft AI initialized');
    },
    
    /**
     * Set up required services
     */
    setupServices() {
        // Initialize openRouter API with site info
        openRouter.init(window.location.origin, 'ChallengeCraft AI');
    },
    
    /**
     * Initialize user progression system
     */
    initProgressionSystem() {
        // Load progression data from storage
        const savedProgression = storage.get('user_progression', null);
        
        if (savedProgression) {
            this.progression = { ...this.progression, ...savedProgression };
        } else {
            // First time user - initialize progression
            this.progression.lastLoginDate = new Date().toISOString();
            storage.set('user_progression', this.progression);
        }
        
        // Update UI with progression data
        this.updateProgressionUI();
    },
    
    /**
     * Update progression UI elements
     */
    updateProgressionUI() {
        const userLevel = document.getElementById('levelDisplay');
        const xpProgress = document.getElementById('xpProgress');
        const streakCount = document.getElementById('streakCount');
        
        if (userLevel) {
            userLevel.textContent = `Level ${this.progression.level}`;
        }
        
        if (xpProgress) {
            const percentage = Math.min(100, (this.progression.xp / this.progression.nextLevelXP) * 100);
            xpProgress.style.width = `${percentage}%`;
            xpProgress.setAttribute('aria-valuenow', percentage);
            xpProgress.parentElement.setAttribute('data-tooltip', `${this.progression.xp}/${this.progression.nextLevelXP} XP`);
        }
        
        if (streakCount) {
            streakCount.textContent = this.progression.streakDays;
        }
        
        // Update badges in profile
        this.updateBadgesUI();
    },
    
    /**
     * Update badges display in UI
     */
    updateBadgesUI() {
        const badgesContainer = document.getElementById('userBadges');
        if (!badgesContainer) return;
        
        badgesContainer.innerHTML = '';
        
        if (this.progression.badges.length === 0) {
            badgesContainer.innerHTML = '<p class="no-badges">Complete challenges to earn badges!</p>';
            return;
        }
        
        this.progression.badges.forEach(badge => {
            const badgeEl = document.createElement('div');
            badgeEl.className = 'badge-item';
            badgeEl.setAttribute('data-tooltip', badge.name);
            
            const icon = document.createElement('i');
            icon.className = this.getBadgeIconClass(badge.id);
            badgeEl.appendChild(icon);
            
            badgesContainer.appendChild(badgeEl);
        });
    },
    
    /**
     * Get CSS class for badge icon
     * @param {string} badgeId - The badge identifier
     * @returns {string} CSS class for the icon
     */
    getBadgeIconClass(badgeId) {
        const iconMap = {
            'streak-7': 'streak-icon',
            'code-ninja': 'code-icon',
            'problem-solver': 'puzzle-icon',
            'creative-genius': 'creative-icon',
            'first-challenge': 'star-icon',
            'perfect-score': 'trophy-icon',
            'expert-challenger': 'expert-icon',
            'quick-thinker': 'time-icon',
            'perfectionist': 'diamond-icon',
            'explorer': 'compass-icon',
            'innovator': 'bulb-icon',
            'rising-star': 'star-icon',
        };
        
        return iconMap[badgeId] || 'default-icon';
    },
    
    /**
     * Check and update login streak
     */
    checkLoginStreak() {
        if (!this.progression.lastLoginDate) {
            this.progression.lastLoginDate = new Date().toISOString();
            this.progression.streakDays = 1;
            storage.set('user_progression', this.progression);
            return;
        }
        
        const lastLogin = new Date(this.progression.lastLoginDate);
        const today = new Date();
        const diffTime = Math.abs(today - lastLogin);
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 1) {
            // Consecutive day login
            this.progression.streakDays += 1;
            
            // Check for streak milestones and award badges
            if (this.progression.streakDays === 7) {
                this.awardBadge('streak-7', 'Week Warrior', 'Logged in for 7 days in a row!');
            } else if (this.progression.streakDays === 30) {
                this.awardBadge('streak-30', 'Monthly Master', 'Logged in for 30 days in a row!');
            }
            
            // Award XP for continuing streak
            this.addXP(10 * Math.min(5, Math.floor(this.progression.streakDays / 5) + 1));
            
            notificationComponent.success(`Day ${this.progression.streakDays} streak! +${10 * Math.min(5, Math.floor(this.progression.streakDays / 5) + 1)} XP`);
        } else if (diffDays > 1) {
            // Streak broken
            if (this.progression.streakDays >= 3) {
                notificationComponent.warning(`Your ${this.progression.streakDays}-day streak has been reset. Log in daily to maintain your streak!`);
            }
            this.progression.streakDays = 1;
        }
        
        this.progression.lastLoginDate = today.toISOString();
        storage.set('user_progression', this.progression);
        this.updateProgressionUI();
    },
    
    /**
     * Award XP to the user
     * @param {number} amount - Amount of XP to award
     * @param {string} [reason] - Reason for the XP award
     */
    addXP(amount, reason = '') {
        this.progression.xp += amount;
        this.progression.totalXP += amount;
        
        // Check for level up
        if (this.progression.xp >= this.progression.nextLevelXP) {
            this.levelUp();
        }
        
        // Save progress
        storage.set('user_progression', this.progression);
        
        // Update UI
        this.updateProgressionUI();
        
        // Show notification
        if (amount > 0) {
            notificationComponent.success(`+${amount} XP ${reason ? '- ' + reason : ''}`);
        }
    },
    
    /**
     * Level up the user
     */
    levelUp() {
        const prevLevel = this.progression.level;
        this.progression.level += 1;
        this.progression.xp = this.progression.xp - this.progression.nextLevelXP;
        this.progression.nextLevelXP = Math.floor(this.progression.nextLevelXP * 1.5);
        
        // Show level up modal
        modalComponent.show({
            title: '🎉 Level Up!',
            content: `
                <div class="level-up-container">
                    <div class="level-badge">${this.progression.level}</div>
                    <h3>Congratulations!</h3>
                    <p>You've reached level ${this.progression.level}!</p>
                    <div class="level-rewards">
                        <h4>Level Rewards:</h4>
                        <ul>
                            <li>New challenge difficulties unlocked</li>
                            <li>+${20 * this.progression.level} XP Bonus</li>
                            ${this.progression.level % 5 === 0 ? '<li>New badge unlocked!</li>' : ''}
                        </ul>
                    </div>
                </div>
            `,
            size: 'small'
        });
        
        // Add level up bonus XP
        this.progression.xp += (20 * this.progression.level);
        this.progression.totalXP += (20 * this.progression.level);
        
        // Award milestone badges
        if (this.progression.level >= 5) {
            this.awardBadge('level-5', 'Apprentice', 'Reached level 5');
        }
        if (this.progression.level >= 10) {
            this.awardBadge('level-10', 'Journeyman', 'Reached level 10');
        }
        if (this.progression.level >= 20) {
            this.awardBadge('level-20', 'Master', 'Reached level 20');
        }
        
        // Save progress
        storage.set('user_progression', this.progression);
    },
    
    /**
     * Award a badge to the user
     * @param {string} badgeId - Badge identifier
     * @param {string} name - Badge name
     * @param {string} description - Badge description
     */
    awardBadge(badgeId, name, description) {
        // Check if user already has this badge
        if (this.progression.badges.some(b => b.id === badgeId)) {
            return false;
        }
        
        // Add badge to user's collection
        this.progression.badges.push({
            id: badgeId,
            name,
            description,
            dateAwarded: new Date().toISOString()
        });
        
        // Save progress
        storage.set('user_progression', this.progression);
        
        // Update UI
        this.updateBadgesUI();
        
        // Show notification
        notificationComponent.show(`🏆 New Badge: ${name}`, 'success', 5000);
        
        // Award XP for badge
        this.addXP(50, `Badge: ${name}`);
        
        return true;
    },
    
    /**
     * Check for daily challenge
     */
    checkDailyChallenge() {
        const lastDailyChallenge = storage.get('last_daily_challenge', null);
        const today = new Date().toDateString();
        
        if (!lastDailyChallenge || lastDailyChallenge.date !== today) {
            // Generate new daily challenge
            this.generateDailyChallenge();
        } else {
            // Show a reminder if daily challenge not completed
            if (!lastDailyChallenge.completed) {
                setTimeout(() => {
                    notificationComponent.info("Don't forget to complete today's daily challenge for bonus rewards!");
                }, 3000);
            }
        }
    },
    
    /**
     * Generate daily challenge
     */
    async generateDailyChallenge() {
        try {
            const userProfile = storage.getUserProfile();
            
            // Use an appropriate difficulty based on user level
            let difficulty = 'beginner';
            if (this.progression.level >= 15) {
                difficulty = 'expert';
            } else if (this.progression.level >= 10) {
                difficulty = 'advanced';
            } else if (this.progression.level >= 5) {
                difficulty = 'intermediate';
            }
            
            // Get random category
            const categories = storage.getCategories();
            const category = categories[Math.floor(Math.random() * categories.length)];
            
            // Generate challenge with API
            const challenge = await openRouter.generateChallenge(userProfile, {
                difficulty,
                categories: [category]
            });
            
            // Mark as daily challenge
            challenge.isDaily = true;
            challenge.dailyDate = new Date().toDateString();
            challenge.bonusXP = 50; // Bonus XP for daily challenges
            challenge.title = `Quick Daily: ${challenge.title}`; // Prefix with "Quick Daily"
            
            // Save daily challenge
            storage.set('daily_challenge', challenge);
            storage.set('last_daily_challenge', {
                date: new Date().toDateString(),
                id: challenge.id,
                completed: false
            });
            
            // Show notification about new daily challenge
            setTimeout(() => {
                notificationComponent.show('🎯 New quick daily challenge available! Complete it in under 15 minutes for bonus rewards.', 'info', 8000);
            }, 2000);
            
        } catch (error) {
            console.error('Error generating daily challenge:', error);
        }
    },
    
    /**
     * Initialize leaderboard system
     */
    initLeaderboard() {
        // Create more realistic but still mock data
        const mockUsers = [
            { name: 'ChallengeChamp', xp: 12500, level: 25, badges: 15, recentChallenges: ['Six-Word Story Challenge', 'Quick Daily: Data Analysis', 'Find Missing Number'] },
            { name: 'CodeMaster', xp: 10200, level: 21, badges: 12, recentChallenges: ['Text Reversal Function', 'Quick Daily: Coding Exercise'] },
            { name: 'PuzzleSolver', xp: 9800, level: 20, badges: 14, recentChallenges: ['2-Minute Focused Breathing', 'One-Page Reading Analysis'] },
            { name: 'DevGuru', xp: 8900, level: 19, badges: 11, recentChallenges: ['Simple Counter Function', 'Create a Simple Game Rule'] },
            { name: 'LogicWhiz', xp: 7500, level: 17, badges: 10, recentChallenges: ['Find the Largest Number'] },
            { name: 'AlgorithmAce', xp: 6200, level: 15, badges: 9, recentChallenges: ['Quick Daily: Logic Puzzle'] },
            { name: 'ByteBender', xp: 5800, level: 14, badges: 8, recentChallenges: ['3-Minute Desk Workout'] },
            { name: 'SyntaxSage', xp: 4900, level: 12, badges: 7, recentChallenges: ['5-Minute Room Tidy'] },
            { name: 'PixelPirate', xp: 4200, level: 11, badges: 6, recentChallenges: ['Quick Daily: Creative Writing'] },
            { name: 'FunctionFinder', xp: 3800, level: 10, badges: 5, recentChallenges: ['Text Reversal Function'] }
        ];
        
        // Add some randomization to the mock data for more realism
        this.leaderboardData = mockUsers.map(user => {
            // Add random last activity between 1 minute and 3 days ago
            const randomMinutes = Math.floor(Math.random() * 60 * 72); // Up to 72 hours (3 days)
            const lastActive = new Date(Date.now() - (randomMinutes * 60 * 1000));
            
            return {
                ...user,
                lastActive
            };
        });
        
        // Get actual challenge history for the player
        const challengeHistory = storage.getChallengeHistory() || [];
        const recentPlayerChallenges = challengeHistory.slice(0, 3).map(c => c.title);
        
        // Add player to leaderboard for demonstration
        const userProfile = storage.getUserProfile();
        const playerEntry = {
            name: userProfile.name,
            xp: this.progression.totalXP,
            level: this.progression.level,
            badges: this.progression.badges.length,
            isPlayer: true,
            lastActive: new Date(),
            recentChallenges: recentPlayerChallenges
        };
        
        // Insert player at appropriate position
        let playerAdded = false;
        for (let i = 0; i < this.leaderboardData.length; i++) {
            if (playerEntry.xp > this.leaderboardData[i].xp) {
                this.leaderboardData.splice(i, 0, playerEntry);
                playerAdded = true;
                break;
            }
        }
        
        // Add player to end if not added and leaderboard not full
        if (!playerAdded && this.leaderboardData.length < 10) {
            this.leaderboardData.push(playerEntry);
        }
        
        // Keep only top 10
        this.leaderboardData = this.leaderboardData.slice(0, 10);
        
        // Update leaderboard periodically
        if (!this.leaderboardInterval) {
            this.leaderboardInterval = setInterval(() => {
                this.updateLeaderboardData();
            }, 60000); // Update every minute
        }
    },
    
    /**
     * Update leaderboard data periodically
     */
    updateLeaderboardData() {
        if (!this.leaderboardData) return;
        
        // Update player entry with latest data
        const playerEntry = this.leaderboardData.find(user => user.isPlayer);
        if (playerEntry) {
            playerEntry.xp = this.progression.totalXP;
            playerEntry.level = this.progression.level;
            playerEntry.badges = this.progression.badges.length;
            
            // Get latest challenge history
            const challengeHistory = storage.getChallengeHistory() || [];
            playerEntry.recentChallenges = challengeHistory.slice(0, 3).map(c => c.title);
        }
        
        // Re-sort the leaderboard based on XP
        this.leaderboardData.sort((a, b) => b.xp - a.xp);
    },
    
    /**
     * Show leaderboard
     */
    showLeaderboard() {
        // Update leaderboard data first
        this.updateLeaderboardData();
        
        // Time formatter function
        const formatLastActive = (date) => {
            const now = new Date();
            const diffMs = now - date;
            const diffMins = Math.floor(diffMs / (1000 * 60));
            
            if (diffMins < 1) return 'Just now';
            if (diffMins < 60) return `${diffMins} min ago`;
            if (diffMins < 60 * 24) return `${Math.floor(diffMins / 60)} hours ago`;
            return `${Math.floor(diffMins / (60 * 24))} days ago`;
        };
        
        let leaderboardHTML = `
            <div class="leaderboard-container">
                <div class="leaderboard-tabs">
                    <button class="leaderboard-tab active" data-tab="rankings">Rankings</button>
                    <button class="leaderboard-tab" data-tab="activity">Recent Activity</button>
                </div>
                
                <div class="leaderboard-content">
                    <div class="leaderboard-tab-content active" id="rankings-content">
                        <table class="leaderboard-table">
                            <thead>
                                <tr>
                                    <th>Rank</th>
                                    <th>Name</th>
                                    <th>Level</th>
                                    <th>XP</th>
                                    <th>Badges</th>
                                    <th>Last Active</th>
                                </tr>
                            </thead>
                            <tbody>
        `;
        
        this.leaderboardData.forEach((user, index) => {
            leaderboardHTML += `
                <tr class="${user.isPlayer ? 'player-row' : ''}">
                    <td>${index + 1}</td>
                    <td>${user.name} ${user.isPlayer ? '(You)' : ''}</td>
                    <td>${user.level}</td>
                    <td>${user.xp.toLocaleString()}</td>
                    <td>${user.badges}</td>
                    <td>${formatLastActive(user.lastActive)}</td>
                </tr>
            `;
        });
        
        leaderboardHTML += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="leaderboard-tab-content" id="activity-content">
                        <div class="recent-activities">
                            <h3>Recent Challenge Completions</h3>
                            <ul class="activity-feed">
        `;
        
        // Add recent activity entries
        this.leaderboardData.forEach(user => {
            if (user.recentChallenges && user.recentChallenges.length > 0) {
                user.recentChallenges.forEach(challenge => {
                    leaderboardHTML += `
                        <li class="activity-feed-item ${user.isPlayer ? 'player-activity' : ''}">
                            <div class="activity-user">${user.name} ${user.isPlayer ? '(You)' : ''}</div>
                            <div class="activity-action">completed</div>
                            <div class="activity-challenge">${challenge}</div>
                        </li>
                    `;
                });
            }
        });
        
        leaderboardHTML += `
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="leaderboard-info">
                    <p>Leaderboard updates as you complete challenges. Earn XP to climb the ranks!</p>
                </div>
            </div>
        `;
        
        const modal = modalComponent.show({
            title: '🏆 Leaderboard',
            content: leaderboardHTML,
            size: 'large',
            onClose: () => {
                // Clean up any event listeners
                const tabButtons = document.querySelectorAll('.leaderboard-tab');
                tabButtons.forEach(button => {
                    button.removeEventListener('click', this.handleTabClick);
                });
            }
        });
        
        // Set up tab switching after the modal is shown
        setTimeout(() => {
            const tabButtons = document.querySelectorAll('.leaderboard-tab');
            tabButtons.forEach(button => {
                button.addEventListener('click', this.handleTabClick);
            });
        }, 100);
    },
    
    /**
     * Handle leaderboard tab clicks
     * @param {Event} e - The click event
     */
    handleTabClick(e) {
        // Remove active class from all tabs and content
        document.querySelectorAll('.leaderboard-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelectorAll('.leaderboard-tab-content').forEach(content => {
            content.classList.remove('active');
        });
        
        // Add active class to clicked tab
        e.target.classList.add('active');
        
        // Show corresponding content
        const tabName = e.target.getAttribute('data-tab');
        document.getElementById(`${tabName}-content`).classList.add('active');
    },
    
    /**
     * Show welcome back message
     */
    showWelcomeBackMessage() {
        const userProfile = storage.getUserProfile();
        const lastLogin = new Date(this.progression.lastLoginDate);
        const today = new Date();
        
        // Only show if not already shown today
        if (lastLogin.toDateString() !== today.toDateString() && this.progression.streakDays > 1) {
            setTimeout(() => {
                notificationComponent.show(`Welcome back, ${userProfile.name}! You're on a ${this.progression.streakDays}-day streak! 🔥`, 'info', 5000);
            }, 1000);
        }
    },
    
    /**
     * Set up global event listeners
     */
    setupEventListeners() {
        // Show settings when settings link is clicked
        const settingsLink = document.querySelector('a[href="#settings"]');
        if (settingsLink) {
            settingsLink.addEventListener('click', (e) => {
                e.preventDefault();
                this.showSettings();
            });
        }
        
        // Show insights when clicking on progress summary
        const progressSummary = document.querySelector('.progress-summary');
        if (progressSummary) {
            progressSummary.addEventListener('click', () => {
                progressTracker.showInsights();
            });
        }
        
        // Leaderboard button
        const leaderboardBtn = document.getElementById('leaderboardBtn');
        if (leaderboardBtn) {
            leaderboardBtn.addEventListener('click', () => {
                this.showLeaderboard();
            });
        }
        
        // Daily challenge button
        const dailyChallengeBtn = document.getElementById('dailyChallengeBtn');
        if (dailyChallengeBtn) {
            dailyChallengeBtn.addEventListener('click', () => {
                this.startDailyChallenge();
            });
        }
        
        // Handle window beforeunload event
        window.addEventListener('beforeunload', (e) => {
            // Check if there's an active challenge with unsaved progress
            const activeChallenge = storage.getCurrentChallenge();
            if (activeChallenge && challengeComponent.timeSpent > 30) {
                // Prompt the user before leaving
                e.preventDefault();
                e.returnValue = 'You have an active challenge in progress. Are you sure you want to leave?';
                return e.returnValue;
            }
        });
    },
    
    /**
     * Start daily challenge
     */
    startDailyChallenge() {
        const dailyChallenge = storage.get('daily_challenge', null);
        
        if (!dailyChallenge) {
            this.generateDailyChallenge().then(() => {
                const newDailyChallenge = storage.get('daily_challenge', null);
                if (newDailyChallenge) {
                    challengeComponent.loadActiveChallenge(newDailyChallenge);
                }
            });
            return;
        }
        
        challengeComponent.loadActiveChallenge(dailyChallenge);
        
        // Update last daily challenge status
        const lastDailyChallenge = storage.get('last_daily_challenge', null);
        if (lastDailyChallenge) {
            lastDailyChallenge.started = true;
            storage.set('last_daily_challenge', lastDailyChallenge);
        }
    },
    
    /**
     * Set up service worker for PWA support
     */
    setupServiceWorker() {
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('/service-worker.js')
                    .then(registration => {
                        console.log('ServiceWorker registration successful with scope: ', registration.scope);
                    })
                    .catch(error => {
                        console.log('ServiceWorker registration failed: ', error);
                    });
            });
        }
    },
    
    /**
     * Set up resize handlers for responsive canvas
     */
    setupResizeHandlers() {
        const resizeCanvas = () => {
            const canvas = document.getElementById('progressChart');
            if (canvas) {
                canvas.width = canvas.parentElement.clientWidth;
                canvas.height = Math.max(300, canvas.parentElement.clientHeight);
                
                // Redraw the chart
                if (progressTracker.chartCanvas) {
                    progressTracker.initChart();
                }
            }
            
            const challengeCanvas = document.getElementById('challengeCanvas');
            if (challengeCanvas && challengeComponent.activeChallenge) {
                challengeCanvas.width = challengeCanvas.parentElement.clientWidth;
                challengeComponent.initCanvas();
            }
        };
        
        // Initial resize
        resizeCanvas();
        
        // Add window resize listener
        window.addEventListener('resize', helpers.debounce(resizeCanvas, 250));
    },
    
    /**
     * Set up theme preference handling
     */
    setupThemePreference() {
        // Check for saved theme preference
        const preferences = storage.getPreferences();
        
        if (preferences.theme) {
            document.documentElement.setAttribute('data-theme', preferences.theme);
        } else {
            // Check system preference
            const prefersDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
            document.documentElement.setAttribute('data-theme', prefersDarkMode ? 'dark' : 'light');
            
            // Save preference
            preferences.theme = prefersDarkMode ? 'dark' : 'light';
            storage.savePreferences(preferences);
        }
        
        // Listen for system preference changes
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
            if (preferences.theme === 'auto') {
                document.documentElement.setAttribute('data-theme', e.matches ? 'dark' : 'light');
            }
        });
    },
    
    /**
     * Show the settings modal
     */
    showSettings() {
        const preferences = storage.getPreferences();
        
        const content = `
            <div class="settings-container">
                <h4>Appearance</h4>
                <div class="settings-group">
                    <label for="themeSelect">Theme</label>
                    <select id="themeSelect" class="form-control">
                        <option value="light" ${preferences.theme === 'light' ? 'selected' : ''}>Light</option>
                        <option value="dark" ${preferences.theme === 'dark' ? 'selected' : ''}>Dark</option>
                        <option value="auto" ${preferences.theme === 'auto' ? 'selected' : ''}>System Default</option>
                    </select>
                </div>
                
                <h4>Challenge Preferences</h4>
                <div class="settings-group">
                    <label for="difficultySelect">Default Difficulty</label>
                    <select id="difficultySelect" class="form-control">
                        <option value="auto" ${preferences.difficulty === 'auto' ? 'selected' : ''}>Automatic (based on performance)</option>
                        <option value="beginner" ${preferences.difficulty === 'beginner' ? 'selected' : ''}>Beginner</option>
                        <option value="intermediate" ${preferences.difficulty === 'intermediate' ? 'selected' : ''}>Intermediate</option>
                        <option value="advanced" ${preferences.difficulty === 'advanced' ? 'selected' : ''}>Advanced</option>
                        <option value="expert" ${preferences.difficulty === 'expert' ? 'selected' : ''}>Expert</option>
                    </select>
                </div>
                
                <h4>Notifications</h4>
                <div class="settings-group settings-checkbox">
                    <label>
                        <input type="checkbox" id="notificationsEnabled" ${preferences.notificationsEnabled ? 'checked' : ''}>
                        Enable notifications
                    </label>
                </div>
                
                <h4>Sound</h4>
                <div class="settings-group settings-checkbox">
                    <label>
                        <input type="checkbox" id="soundEnabled" ${preferences.soundEnabled ? 'checked' : ''}>
                        Enable sound effects
                    </label>
                </div>
                
                <h4>Weekly Goals</h4>
                <div class="settings-group">
                    <label for="weeklyGoalSelect">Challenges per week</label>
                    <select id="weeklyGoalSelect" class="form-control">
                        <option value="3" ${this.progression.weeklyGoal === 3 ? 'selected' : ''}>3 Challenges</option>
                        <option value="5" ${this.progression.weeklyGoal === 5 ? 'selected' : ''}>5 Challenges</option>
                        <option value="7" ${this.progression.weeklyGoal === 7 ? 'selected' : ''}>7 Challenges</option>
                        <option value="10" ${this.progression.weeklyGoal === 10 ? 'selected' : ''}>10 Challenges</option>
                    </select>
                </div>
                
                <h4>Display Name</h4>
                <div class="settings-group">
                    <label for="displayName">Your Name</label>
                    <input type="text" id="displayName" class="form-control" value="${storage.getUserProfile().name}">
                    <p class="settings-description">This name will be used on the leaderboard.</p>
                </div>
                
                <div class="danger-zone">
                    <h4>Data Management</h4>
                    <div class="settings-group">
                        <button id="clearDataBtn" class="btn btn-danger">Clear All Data</button>
                        <p class="settings-description">This will reset all progress and preferences.</p>
                    </div>
                </div>
            </div>
        `;
        
        const modal = modalComponent.show({
            title: 'Settings',
            content: content,
            size: 'large',
            buttons: [
                {
                    text: 'Save Changes',
                    action: () => this.saveSettings(),
                    className: 'btn-primary'
                },
                {
                    text: 'Cancel',
                    action: 'close',
                    className: 'btn-secondary'
                }
            ]
        });
        
        // Add event listeners for settings buttons
        setTimeout(() => {
            const clearDataBtn = document.getElementById('clearDataBtn');
            if (clearDataBtn) {
                clearDataBtn.addEventListener('click', () => {
                    modalComponent.confirm(
                        'Are you sure you want to clear all data? This action cannot be undone.',
                        () => {
                            storage.clearAll();
                            notificationComponent.success('All data has been cleared.');
                            modalComponent.hide();
                            setTimeout(() => window.location.reload(), 1000);
                        },
                        null,
                        {
                            title: 'Confirm Data Reset',
                            confirmText: 'Yes, Clear All Data',
                            confirmClass: 'btn-danger'
                        }
                    );
                });
            }
        }, 100);
    },
    
    /**
     * Save settings from the settings modal
     */
    saveSettings() {
        const preferences = storage.getPreferences();
        const userProfile = storage.getUserProfile();
        
        // Get updated values
        const themeSelect = document.getElementById('themeSelect');
        const difficultySelect = document.getElementById('difficultySelect');
        const notificationsEnabled = document.getElementById('notificationsEnabled');
        const soundEnabled = document.getElementById('soundEnabled');
        const weeklyGoalSelect = document.getElementById('weeklyGoalSelect');
        const displayName = document.getElementById('displayName');
        
        if (themeSelect) {
            preferences.theme = themeSelect.value;
            document.documentElement.setAttribute('data-theme', themeSelect.value === 'auto' ? 
                (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') : 
                themeSelect.value);
        }
        
        if (difficultySelect) {
            preferences.difficulty = difficultySelect.value;
        }
        
        if (notificationsEnabled) {
            preferences.notificationsEnabled = notificationsEnabled.checked;
        }
        
        if (soundEnabled) {
            preferences.soundEnabled = soundEnabled.checked;
        }
        
        if (weeklyGoalSelect) {
            this.progression.weeklyGoal = parseInt(weeklyGoalSelect.value, 10);
            storage.set('user_progression', this.progression);
        }
        
        if (displayName && displayName.value.trim()) {
            userProfile.name = displayName.value.trim();
            storage.saveUserProfile(userProfile);
        }
        
        // Save preferences
        storage.savePreferences(preferences);
        
        // Close modal
        modalComponent.hide();
        
        // Show success notification
        notificationComponent.success('Settings saved successfully!');
    },
    
    /**
     * Hide the loading indicator
     */
    hideLoading() {
        const loadingIndicator = document.getElementById('loadingIndicator');
        if (loadingIndicator) {
            loadingIndicator.classList.add('hidden');
            setTimeout(() => {
                loadingIndicator.style.display = 'none';
            }, 500);
        }
    }
};

// Initialize the application when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    app.init();
});

// Make app available globally
window.app = app; 