/**
 * Helper utility functions for ChallengeCraft AI
 */

const helpers = {
    /**
     * Get element by ID with error handling
     * @param {string} id - The ID of the element to get
     * @returns {HTMLElement} The element with the specified ID
     */
    getElement(id) {
        const element = document.getElementById(id);
        if (!element) {
            console.error(`Element with ID "${id}" not found`);
        }
        return element;
    },

    /**
     * Create an element with attributes and optional inner content
     * @param {string} tag - The tag name of the element to create
     * @param {Object} attributes - The attributes to set on the element
     * @param {string|HTMLElement} [content] - The content to add to the element
     * @returns {HTMLElement} The created element
     */
    createElement(tag, attributes = {}, content = null) {
        const element = document.createElement(tag);
        
        Object.entries(attributes).forEach(([key, value]) => {
            if (key === 'className') {
                element.className = value;
            } else if (key === 'dataset') {
                Object.entries(value).forEach(([dataKey, dataValue]) => {
                    element.dataset[dataKey] = dataValue;
                });
            } else {
                element.setAttribute(key, value);
            }
        });
        
        if (content) {
            if (typeof content === 'string') {
                element.innerHTML = content;
            } else {
                element.appendChild(content);
            }
        }
        
        return element;
    },

    /**
     * Format a date to a human-readable string
     * @param {Date|string|number} date - The date to format
     * @param {boolean} [includeTime=false] - Whether to include the time
     * @returns {string} The formatted date string
     */
    formatDate(date, includeTime = false) {
        const dateObj = new Date(date);
        const options = {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
        };
        
        if (includeTime) {
            options.hour = '2-digit';
            options.minute = '2-digit';
        }
        
        return dateObj.toLocaleDateString('en-US', options);
    },

    /**
     * Format time in seconds to MM:SS format
     * @param {number} seconds - The seconds to format
     * @returns {string} The formatted time string
     */
    formatTime(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    },

    /**
     * Debounce a function call
     * @param {Function} func - The function to debounce
     * @param {number} wait - The time to wait in milliseconds
     * @returns {Function} The debounced function
     */
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    /**
     * Throttle a function call
     * @param {Function} func - The function to throttle
     * @param {number} limit - The time limit in milliseconds
     * @returns {Function} The throttled function
     */
    throttle(func, limit) {
        let lastFunc;
        let lastRan;
        return function executedFunction(...args) {
            if (!lastRan) {
                func(...args);
                lastRan = Date.now();
            } else {
                clearTimeout(lastFunc);
                lastFunc = setTimeout(() => {
                    if (Date.now() - lastRan >= limit) {
                        func(...args);
                        lastRan = Date.now();
                    }
                }, limit - (Date.now() - lastRan));
            }
        };
    },

    /**
     * Generate a unique ID
     * @returns {string} A unique ID
     */
    generateId() {
        return 'id_' + Math.random().toString(36).substring(2, 9) + Date.now().toString(36);
    },

    /**
     * Truncate a string to a specified length and add ellipsis
     * @param {string} str - The string to truncate
     * @param {number} length - The maximum length
     * @returns {string} The truncated string
     */
    truncateString(str, length) {
        if (str.length <= length) return str;
        return str.slice(0, length) + '...';
    },

    /**
     * Show an element by removing the 'hidden' class
     * @param {HTMLElement|string} element - The element or element ID to show
     */
    showElement(element) {
        const el = typeof element === 'string' ? this.getElement(element) : element;
        if (el) {
            el.classList.remove('hidden');
        }
    },

    /**
     * Hide an element by adding the 'hidden' class
     * @param {HTMLElement|string} element - The element or element ID to hide
     */
    hideElement(element) {
        const el = typeof element === 'string' ? this.getElement(element) : element;
        if (el) {
            el.classList.add('hidden');
        }
    },

    /**
     * Check if element is currently visible (doesn't have 'hidden' class)
     * @param {HTMLElement|string} element - The element or element ID to check
     * @returns {boolean} Whether the element is visible
     */
    isVisible(element) {
        const el = typeof element === 'string' ? this.getElement(element) : element;
        return el && !el.classList.contains('hidden');
    },

    /**
     * Toggle the visibility of an element
     * @param {HTMLElement|string} element - The element or element ID to toggle
     */
    toggleElement(element) {
        const el = typeof element === 'string' ? this.getElement(element) : element;
        if (el) {
            el.classList.toggle('hidden');
        }
    },

    /**
     * Add a class to an element with optional animation duration
     * @param {HTMLElement|string} element - The element or element ID
     * @param {string} className - The class to add
     * @param {number} [duration] - Duration in ms after which to remove the class
     */
    addClass(element, className, duration = 0) {
        const el = typeof element === 'string' ? this.getElement(element) : element;
        if (el) {
            el.classList.add(className);
            if (duration > 0) {
                setTimeout(() => {
                    el.classList.remove(className);
                }, duration);
            }
        }
    },

    /**
     * Calculate difficulty level based on user performance
     * @param {Object} performance - User performance metrics
     * @returns {string} The calculated difficulty level
     */
    calculateDifficulty(performance) {
        const { successRate, completedChallenges, averageTime } = performance;
        
        if (completedChallenges < 3) return 'beginner';
        
        if (successRate > 80 && averageTime < 120) {
            return 'expert';
        } else if (successRate > 60 && averageTime < 180) {
            return 'advanced';
        } else if (successRate > 40) {
            return 'intermediate';
        } else {
            return 'beginner';
        }
    },

    /**
     * Sanitize HTML content to prevent XSS
     * @param {string} html - The HTML string to sanitize
     * @returns {string} The sanitized HTML
     */
    sanitizeHTML(html) {
        const temp = document.createElement('div');
        temp.textContent = html;
        return temp.innerHTML;
    },

    /**
     * Smooth scroll to an element
     * @param {HTMLElement|string} element - The element or element ID to scroll to
     * @param {number} [offset=0] - The offset from the top of the element
     * @param {number} [duration=500] - The duration of the scroll animation
     */
    scrollToElement(element, offset = 0, duration = 500) {
        const el = typeof element === 'string' ? this.getElement(element) : element;
        if (!el) return;
        
        const targetPosition = el.getBoundingClientRect().top + window.pageYOffset - offset;
        const startPosition = window.pageYOffset;
        const distance = targetPosition - startPosition;
        let startTime = null;
        
        function animation(currentTime) {
            if (startTime === null) startTime = currentTime;
            const timeElapsed = currentTime - startTime;
            const scrollY = ease(timeElapsed, startPosition, distance, duration);
            window.scrollTo(0, scrollY);
            if (timeElapsed < duration) requestAnimationFrame(animation);
        }
        
        // Easing function
        function ease(t, b, c, d) {
            t /= d / 2;
            if (t < 1) return c / 2 * t * t + b;
            t--;
            return -c / 2 * (t * (t - 2) - 1) + b;
        }
        
        requestAnimationFrame(animation);
    },

    /**
     * Check if a value is empty (null, undefined, empty string, empty array)
     * @param {*} value - The value to check
     * @returns {boolean} Whether the value is empty
     */
    isEmpty(value) {
        if (value === null || value === undefined) return true;
        if (typeof value === 'string') return value.trim() === '';
        if (Array.isArray(value)) return value.length === 0;
        if (typeof value === 'object') return Object.keys(value).length === 0;
        return false;
    }
};

// Make helpers available globally
window.helpers = helpers; 