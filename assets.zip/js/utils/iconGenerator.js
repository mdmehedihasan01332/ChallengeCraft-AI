/**
 * Icon Generator Utility for ChallengeCraft AI
 * 
 * This utility generates SVG-based app icons and saves them as files
 * to be used by the Progressive Web App. It creates the necessary
 * icon sizes for various devices and platforms.
 */
const IconGenerator = {
    /**
     * Generate a basic SVG icon with the given size
     * @param {number} size - The size of the icon in pixels
     * @returns {string} - SVG markup as a string
     */
    generateSVG(size) {
        // Create gradient colors for a modern look
        const primaryColor = '#4a6bff';
        const secondaryColor = '#45caff';
        const accentColor = '#ff7b9c';
        
        return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
            <defs>
                <linearGradient id="bg-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="${primaryColor}" />
                    <stop offset="100%" stop-color="${secondaryColor}" />
                </linearGradient>
                <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
                    <feGaussianBlur stdDeviation="3" />
                </filter>
            </defs>
            
            <!-- Background -->
            <rect width="${size}" height="${size}" rx="${size * 0.2}" fill="url(#bg-gradient)" />
            
            <!-- Logo Elements -->
            <g fill="white" transform="translate(${size * 0.2}, ${size * 0.2}) scale(${size * 0.006})">
                <!-- Stylized 'C' letters for ChallengeCraft -->
                <path d="M50,20 C70,20 90,40 90,60 L70,60 C70,50 60,40 50,40 C40,40 30,50 30,60 C30,70 40,80 50,80 C60,80 70,70 70,60 L90,60 C90,80 70,100 50,100 C30,100 10,80 10,60 C10,40 30,20 50,20 Z" />
                
                <!-- Small 'C' for Craft -->
                <path d="M80,40 C90,40 100,50 100,60 L90,60 C90,55 85,50 80,50 C75,50 70,55 70,60 C70,65 75,70 80,70 C85,70 90,65 90,60 L100,60 C100,70 90,80 80,80 C70,80 60,70 60,60 C60,50 70,40 80,40 Z" transform="translate(0, 0)" />
                
                <!-- AI element -->
                <path d="M60,30 L70,70 L50,70 Z" fill="${accentColor}" transform="translate(30, 0)" />
            </g>
        </svg>`;
    },
    
    /**
     * Convert an SVG to a data URL
     * @param {string} svg - SVG markup as a string
     * @returns {string} - Data URL representation of the SVG
     */
    svgToDataURL(svg) {
        const encodedSVG = encodeURIComponent(svg);
        return `data:image/svg+xml;charset=utf-8,${encodedSVG}`;
    },
    
    /**
     * Save the SVG as a file using fetch API
     * @param {string} svg - SVG markup as a string
     * @param {string} filename - The name to save the file as
     * @returns {Promise} - Promise that resolves when the file is saved
     */
    async saveSVG(svg, filename) {
        const blob = new Blob([svg], { type: 'image/svg+xml' });
        
        // For browsers that support the File System Access API
        if ('showSaveFilePicker' in window) {
            try {
                const handle = await window.showSaveFilePicker({
                    suggestedName: filename,
                    types: [{
                        description: 'SVG File',
                        accept: { 'image/svg+xml': ['.svg'] },
                    }],
                });
                
                const writable = await handle.createWritable();
                await writable.write(blob);
                await writable.close();
                return true;
            } catch (err) {
                console.error('Error saving file:', err);
                return this.fallbackSave(blob, filename);
            }
        } else {
            return this.fallbackSave(blob, filename);
        }
    },
    
    /**
     * Fallback method to save files using download attribute
     * @param {Blob} blob - The blob to save
     * @param {string} filename - The name to save the file as
     * @returns {boolean} - Whether the operation was successful
     */
    fallbackSave(blob, filename) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        return true;
    },
    
    /**
     * Generate all required icon sizes for the PWA
     * @returns {Object} - Object containing all generated icons as data URLs
     */
    generateAllIcons() {
        const sizes = [72, 96, 128, 144, 152, 192, 384, 512];
        const icons = {};
        
        sizes.forEach(size => {
            const svg = this.generateSVG(size);
            icons[size] = this.svgToDataURL(svg);
        });
        
        return icons;
    },
    
    /**
     * Creates a temporary image element with the icon
     * @param {number} size - The size of the icon
     * @returns {HTMLImageElement} - The image element
     */
    createIconPreview(size = 192) {
        const svg = this.generateSVG(size);
        const dataURL = this.svgToDataURL(svg);
        
        const img = document.createElement('img');
        img.src = dataURL;
        img.width = size;
        img.height = size;
        img.style.display = 'block';
        img.style.margin = '20px auto';
        img.style.borderRadius = '16px';
        img.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';
        
        return img;
    },
    
    /**
     * Insert icon preview into the DOM
     * @param {HTMLElement} container - The container element to append to
     * @param {number} size - The size of the icon
     */
    insertIconPreview(container, size = 192) {
        const img = this.createIconPreview(size);
        container.appendChild(img);
    }
};

// Export the module
if (typeof module !== 'undefined' && module.exports) {
    module.exports = IconGenerator;
} 