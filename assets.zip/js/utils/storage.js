/**
 * Storage and state management utilities for ChallengeCraft AI
 */

const storage = {
    /**
     * Storage prefix for all keys
     */
    prefix: 'challengecraft_',

    /**
     * Store data in localStorage with the app prefix
     * @param {string} key - The key to store the data under
     * @param {*} data - The data to store
     */
    set(key, data) {
        try {
            const serializedData = JSON.stringify(data);
            localStorage.setItem(this.prefix + key, serializedData);
        } catch (error) {
            console.error('Error setting localStorage item:', error);
        }
    },

    /**
     * Retrieve data from localStorage
     * @param {string} key - The key to retrieve data from
     * @param {*} [defaultValue=null] - The default value to return if the key doesn't exist
     * @returns {*} The retrieved data or defaultValue if not found
     */
    get(key, defaultValue = null) {
        try {
            const serializedData = localStorage.getItem(this.prefix + key);
            if (serializedData === null) {
                return defaultValue;
            }
            return JSON.parse(serializedData);
        } catch (error) {
            console.error('Error getting localStorage item:', error);
            return defaultValue;
        }
    },

    /**
     * Remove data from localStorage
     * @param {string} key - The key to remove
     */
    remove(key) {
        try {
            localStorage.removeItem(this.prefix + key);
        } catch (error) {
            console.error('Error removing localStorage item:', error);
        }
    },

    /**
     * Clear all app data from localStorage
     */
    clearAll() {
        try {
            Object.keys(localStorage).forEach(key => {
                if (key.startsWith(this.prefix)) {
                    localStorage.removeItem(key);
                }
            });
        } catch (error) {
            console.error('Error clearing localStorage items:', error);
        }
    },

    /**
     * Get the user profile from storage
     * @returns {Object} The user profile or an empty object
     */
    getUserProfile() {
        return this.get('user_profile', {
            id: helpers.generateId(),
            name: 'Guest User',
            createdAt: new Date().toISOString(),
            preferences: {
                difficulty: 'beginner',
                categories: ['all']
            }
        });
    },

    /**
     * Save the user profile to storage
     * @param {Object} profile - The user profile to save
     */
    saveUserProfile(profile) {
        this.set('user_profile', profile);
    },

    /**
     * Get the user's challenge history
     * @returns {Array} The user's challenge history
     */
    getChallengeHistory() {
        return this.get('challenge_history', []);
    },

    /**
     * Add a challenge to the user's history
     * @param {Object} challenge - The challenge to add
     */
    addChallengeToHistory(challenge) {
        const history = this.getChallengeHistory();
        history.unshift({
            ...challenge,
            completedAt: new Date().toISOString()
        });
        this.set('challenge_history', history);
    },

    /**
     * Get the user's performance stats
     * @returns {Object} The user's performance stats
     */
    getPerformanceStats() {
        return this.get('performance_stats', {
            completedChallenges: 0,
            successfulChallenges: 0,
            totalTimeSpent: 0,
            streak: 0,
            lastCompletedDate: null,
            badges: []
        });
    },

    /**
     * Update the user's performance stats
     * @param {Object} stats - The stats to update
     */
    updatePerformanceStats(stats) {
        const currentStats = this.getPerformanceStats();
        this.set('performance_stats', {
            ...currentStats,
            ...stats
        });
    },

    /**
     * Calculate and update user streak
     * @param {boolean} completed - Whether the challenge was completed successfully
     */
    updateStreak(completed) {
        const stats = this.getPerformanceStats();
        const today = new Date().toDateString();
        const lastCompletedDate = stats.lastCompletedDate ? new Date(stats.lastCompletedDate).toDateString() : null;
        
        // If the last completion was yesterday, increment streak
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayString = yesterday.toDateString();
        
        if (completed) {
            if (lastCompletedDate === today) {
                // Already completed a challenge today, streak unchanged
            } else if (lastCompletedDate === yesterdayString) {
                // Completed yesterday, increment streak
                stats.streak += 1;
            } else {
                // Streak broken or first completion
                stats.streak = 1;
            }
            
            stats.lastCompletedDate = new Date().toISOString();
        } else if (lastCompletedDate !== today) {
            // Failed challenge and haven't completed one today
            stats.streak = 0;
        }
        
        this.updatePerformanceStats(stats);
        return stats.streak;
    },

    /**
     * Save the current challenge
     * @param {Object} challenge - The current challenge
     */
    saveCurrentChallenge(challenge) {
        this.set('current_challenge', challenge);
    },

    /**
     * Get the current challenge
     * @returns {Object|null} The current challenge or null
     */
    getCurrentChallenge() {
        return this.get('current_challenge', null);
    },

    /**
     * Clear the current challenge
     */
    clearCurrentChallenge() {
        this.remove('current_challenge');
    },

    /**
     * Save user preferences
     * @param {Object} preferences - The user preferences
     */
    savePreferences(preferences) {
        this.set('preferences', preferences);
    },

    /**
     * Get user preferences
     * @returns {Object} The user preferences
     */
    getPreferences() {
        return this.get('preferences', {
            theme: 'light',
            notificationsEnabled: true,
            soundEnabled: true,
            difficulty: 'auto'
        });
    },

    /**
     * Store challenge categories
     * @param {Array} categories - The challenge categories
     */
    saveCategories(categories) {
        this.set('categories', categories);
    },

    /**
     * Get challenge categories
     * @returns {Array} The challenge categories
     */
    getCategories() {
        return this.get('categories', [
            'coding',
            'creativity',
            'problem-solving',
            'design',
            'real-life',
            'book-challenge',
            'gameplay',
            'language-learning',
            'fitness',
            'art',
            'writing',
            'music',
            'cooking',
            'trivia',
            'mindfulness',
            'productivity'
        ]);
    }
};

// Make storage available globally
window.storage = storage; 