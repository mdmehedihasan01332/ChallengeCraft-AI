/**
 * OpenRouter API integration for ChallengeCraft AI
 */

const openRouter = {
    /**
     * API configuration
     */
    config: {
        baseUrl: 'https://openrouter.ai/api/v1',
        defaultModel: 'qwen/qwen3-30b-a3b:free',
        defaultHeaders: {
            'Content-Type': 'application/json'
        },
        timeout: 30000, // 30 seconds
        apiKey: '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' // Using app owner's API key
    },

    /**
     * Initialize the OpenRouter API
     * @param {string} [siteUrl] - The site URL for rankings
     * @param {string} [siteName] - The site name for rankings
     */
    init(siteUrl = null, siteName = null) {
        this.siteUrl = siteUrl;
        this.siteName = siteName;
        console.log('OpenRouter API initialized with app owner\'s API key');
    },

    /**
     * Check if API is configured (always returns true now that we're using a predefined key)
     * @returns {boolean} Always true
     */
    isConfigured() {
        return true;
    },

    /**
     * Create headers for API requests
     * @returns {Object} The headers object
     */
    createHeaders() {
        const headers = { ...this.config.defaultHeaders };
        headers['Authorization'] = `Bearer ${this.config.apiKey}`;
        
        if (this.siteUrl) {
            headers['HTTP-Referer'] = this.siteUrl;
        }
        
        if (this.siteName) {
            headers['X-Title'] = this.siteName;
        }
        
        return headers;
    },

    /**
     * Generate a chat completion
     * @param {Array} messages - The messages for the chat
     * @param {string} [model] - The model to use
     * @param {Object} [options] - Additional options for the request
     * @returns {Promise<Object>} The response data
     */
    async generateChatCompletion(messages, model = null, options = {}) {
        const targetModel = model || this.config.defaultModel;
        
        try {
            const response = await fetch(`${this.config.baseUrl}/chat/completions`, {
                method: 'POST',
                headers: this.createHeaders(),
                body: JSON.stringify({
                    model: targetModel,
                    messages: messages,
                    ...options
                }),
                signal: AbortSignal.timeout(this.config.timeout)
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(`OpenRouter API Error: ${response.status} - ${errorData.error?.message || response.statusText}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error generating chat completion:', error);
            throw error;
        }
    },

    /**
     * Generate a dynamic challenge based on user profile and preferences
     * @param {Object} userProfile - The user profile
     * @param {Object} [options] - Additional options for the challenge
     * @returns {Promise<Object>} The generated challenge
     */
    async generateChallenge(userProfile, options = {}) {
        const { difficulty, categories } = options;
        
        const userLevel = difficulty || helpers.calculateDifficulty({
            successRate: userProfile.successfulChallenges / Math.max(1, userProfile.completedChallenges) * 100,
            completedChallenges: userProfile.completedChallenges || 0,
            averageTime: userProfile.totalTimeSpent / Math.max(1, userProfile.completedChallenges)
        });
        
        const category = categories && categories.length > 0 ? 
            categories[Math.floor(Math.random() * categories.length)] : 
            'general';
        
        const messages = [
            {
                role: 'system',
                content: `You are an AI challenge creator for a platform called ChallengeCraft AI. 
                Create a ${userLevel} level micro-challenge in the ${category} category. 
                The challenge should be engaging, creative, and appropriate for the difficulty level.
                
                IMPORTANT: Create a very small, focused task that can be completed in 5-15 minutes. The challenge should be specific and have a clear goal.
                
                Structure your response as a JSON object with the following fields:
                - title: A catchy title for the challenge (keep it short and specific)
                - description: A brief description of the challenge (2-3 sentences maximum)
                - instructions: Concise step-by-step instructions (keep it to 2-4 simple steps)
                - difficulty: The difficulty level (beginner, intermediate, advanced, expert)
                - category: The challenge category
                - estimatedTime: Estimated time to complete in minutes (between 5-15 minutes)
                - criteria: An array of success criteria for evaluating submissions (2-3 simple criteria)
                - hints: An array with ONE helpful hint (without giving away the solution)
                - resources: An array with ONE helpful resource or reference
                - xpPoints: Experience points to award (30-100 based on difficulty)
                - badges: ONE potential badge that can be earned (e.g., "First Coder", "Problem Solver")`
            },
            {
                role: 'user',
                content: `Generate a quick ${userLevel} difficulty ${category} micro-challenge for me. Make it something I can complete in under 15 minutes!`
            }
        ];
        
        try {
            const completion = await this.generateChatCompletion(messages, null, {
                temperature: 0.8,
                max_tokens: 1000
            });
            
            const responseContent = completion.choices[0].message.content;
            let challenge;
            
            try {
                // Try to parse the JSON response
                challenge = JSON.parse(responseContent);
            } catch (parseError) {
                // If not valid JSON, extract the key information using regex
                challenge = this.extractChallengeFromText(responseContent);
            }
            
            // Add metadata
            challenge.id = helpers.generateId();
            challenge.createdAt = new Date().toISOString();
            
            // Add gamification elements if not present
            if (!challenge.xpPoints) {
                challenge.xpPoints = this.calculateXPPoints(challenge.difficulty);
            }
            
            if (!challenge.badges) {
                challenge.badges = this.generateBadgesForChallenge(challenge.category, challenge.difficulty);
            }
            
            return challenge;
        } catch (error) {
            console.error('Error generating challenge:', error);
            
            // Return a fallback challenge if API fails
            return this.getFallbackChallenge(userLevel, category);
        }
    },

    /**
     * Calculate XP points based on difficulty
     * @param {string} difficulty - The difficulty level
     * @returns {number} XP points to award
     */
    calculateXPPoints(difficulty) {
        switch(difficulty) {
            case 'beginner': return Math.floor(Math.random() * 51) + 50; // 50-100
            case 'intermediate': return Math.floor(Math.random() * 101) + 100; // 100-200
            case 'advanced': return Math.floor(Math.random() * 151) + 200; // 200-350
            case 'expert': return Math.floor(Math.random() * 151) + 350; // 350-500
            default: return 100;
        }
    },

    /**
     * Generate relevant badges for a challenge
     * @param {string} category - The challenge category
     * @param {string} difficulty - The difficulty level
     * @returns {Array} Potential badges
     */
    generateBadgesForChallenge(category, difficulty) {
        const badges = [];
        
        // Category-specific badges
        if (category === 'coding') {
            badges.push('Code Ninja');
            if (difficulty === 'expert') badges.push('Master Coder');
        } else if (category === 'problem-solving') {
            badges.push('Problem Solver');
            if (difficulty === 'expert') badges.push('Logic Master');
        } else if (category === 'creativity') {
            badges.push('Creative Genius');
        } else if (category === 'design') {
            badges.push('Design Wizard');
        } else if (category === 'real-life') {
            badges.push('Life Hacker');
        } else if (category === 'book-challenge') {
            badges.push('Bookworm');
        } else if (category === 'gameplay') {
            badges.push('Game Master');
        } else if (category === 'language-learning') {
            badges.push('Polyglot');
        } else if (category === 'fitness') {
            badges.push('Fitness Guru');
        } else if (category === 'art') {
            badges.push('Art Virtuoso');
        } else if (category === 'writing') {
            badges.push('Wordsmith');
        } else if (category === 'music') {
            badges.push('Melody Maker');
        } else if (category === 'cooking') {
            badges.push('Chef Extraordinaire');
        } else if (category === 'trivia') {
            badges.push('Knowledge Keeper');
        } else if (category === 'mindfulness') {
            badges.push('Zen Master');
        } else if (category === 'productivity') {
            badges.push('Efficiency Expert');
        }
        
        // Difficulty badges
        if (difficulty === 'expert') {
            badges.push('Expert Challenger');
        } else if (difficulty === 'advanced') {
            badges.push('Advanced Thinker');
        }
        
        // Add a random special badge occasionally
        if (Math.random() > 0.7) {
            const specialBadges = ['Quick Thinker', 'Perfectionist', 'Explorer', 'Innovator', 'Rising Star'];
            badges.push(specialBadges[Math.floor(Math.random() * specialBadges.length)]);
        }
        
        return badges;
    },

    /**
     * Extract challenge information from text that isn't valid JSON
     * @param {string} text - The text to extract from
     * @returns {Object} The extracted challenge
     */
    extractChallengeFromText(text) {
        const challenge = {
            title: this.extractProperty(text, 'title') || 'Challenge',
            description: this.extractProperty(text, 'description') || 'Complete this challenge!',
            instructions: this.extractProperty(text, 'instructions') || 'Follow the steps to complete the challenge.',
            difficulty: this.extractProperty(text, 'difficulty') || 'beginner',
            category: this.extractProperty(text, 'category') || 'general',
            estimatedTime: parseInt(this.extractProperty(text, 'estimatedTime'), 10) || 15,
            criteria: this.extractArray(text, 'criteria') || ['Complete the challenge successfully'],
            hints: this.extractArray(text, 'hints') || ['Think creatively!'],
            resources: this.extractArray(text, 'resources') || []
        };
        
        return challenge;
    },

    /**
     * Extract a property from text using regex
     * @param {string} text - The text to extract from
     * @param {string} property - The property name to extract
     * @returns {string|null} The extracted property or null
     */
    extractProperty(text, property) {
        const regex = new RegExp(`["']?${property}["']?\\s*:\\s*["'](.+?)["']`, 'i');
        const match = text.match(regex);
        return match ? match[1] : null;
    },

    /**
     * Extract an array property from text
     * @param {string} text - The text to extract from
     * @param {string} property - The array property name
     * @returns {Array|null} The extracted array or null
     */
    extractArray(text, property) {
        const startPattern = new RegExp(`["']?${property}["']?\\s*:\\s*\\[`, 'i');
        const startMatch = text.match(startPattern);
        
        if (!startMatch) return null;
        
        const startIndex = startMatch.index + startMatch[0].length;
        let bracketCount = 1;
        let endIndex = startIndex;
        
        for (let i = startIndex; i < text.length; i++) {
            if (text[i] === '[') bracketCount++;
            if (text[i] === ']') bracketCount--;
            
            if (bracketCount === 0) {
                endIndex = i;
                break;
            }
        }
        
        if (bracketCount !== 0) return null;
        
        const arrayText = text.substring(startIndex, endIndex);
        const items = arrayText.split(',').map(item => {
            return item.trim().replace(/^["']|["']$/g, '');
        }).filter(item => item);
        
        return items;
    },

    /**
     * Get a fallback challenge if API generation fails
     * @param {string} difficulty - The difficulty level
     * @param {string} category - The challenge category
     * @returns {Object} A fallback challenge
     */
    getFallbackChallenge(difficulty, category) {
        const fallbackChallenges = {
            beginner: {
                coding: {
                    title: "Simple Counter Function",
                    description: "Create a basic function that counts from 1 to 10 and logs the numbers to the console.",
                    instructions: "Write a function that uses a for loop to iterate from 1 to 10 and console.log each number.",
                    estimatedTime: 10,
                    criteria: ["Function correctly logs numbers 1-10", "Use of proper loop syntax"],
                    hints: ["Remember that for loops have three parts: initialization, condition, and increment."]
                },
                "problem-solving": {
                    title: "Find the Largest Number",
                    description: "Write a simple function to find the largest number in an array of five numbers.",
                    instructions: "Create a function that takes an array of numbers and returns the largest value.",
                    estimatedTime: 12,
                    criteria: ["Function correctly identifies the largest number", "Handles negative numbers correctly"],
                    hints: ["You can use Math.max() or create your own comparison logic."]
                },
                "real-life": {
                    title: "5-Minute Room Tidy",
                    description: "Quickly organize one small area of your living space within 5 minutes.",
                    instructions: "Choose one small area (desk, nightstand, coffee table) and organize it in just 5 minutes.",
                    estimatedTime: 5,
                    criteria: ["Area is visibly more organized", "Completed within the time limit"],
                    hints: ["Focus on the most visible items first."]
                },
                "book-challenge": {
                    title: "One-Page Reading Analysis",
                    description: "Read one page from any book and identify the main theme or message.",
                    instructions: "Select a page, read it carefully, and write down the main point in one or two sentences.",
                    estimatedTime: 10,
                    criteria: ["Clear identification of main theme", "Concise summary"],
                    hints: ["Look for repeated ideas or concluding statements."]
                },
                "gameplay": {
                    title: "Create a Simple Game Rule",
                    description: "Invent one new rule for a familiar game to make it more interesting.",
                    instructions: "Think of a game you know well and create one new rule that would change gameplay in an interesting way.",
                    estimatedTime: 8,
                    criteria: ["Rule is clear and specific", "Rule creates meaningful change in gameplay"],
                    hints: ["Consider how your rule might create new strategic options."]
                }
            },
            intermediate: {
                coding: {
                    title: "Text Reversal Function",
                    description: "Create a function that reverses the characters in a string without using built-in reverse methods.",
                    instructions: "Write a function that takes a string and returns it with characters in reverse order.",
                    estimatedTime: 15,
                    criteria: ["Function correctly reverses text", "Handles spaces and special characters"],
                    hints: ["Consider using a loop that works backwards through the string."]
                },
                "problem-solving": {
                    title: "Find Missing Number",
                    description: "Identify the missing number in a sequence of otherwise consecutive integers.",
                    instructions: "Create a function that finds the missing number in an array like [1,2,3,5,6].",
                    estimatedTime: 12,
                    criteria: ["Correctly identifies the missing number", "Works with different sequences"],
                    hints: ["The sum of consecutive integers has a mathematical formula you can use."]
                },
                "fitness": {
                    title: "3-Minute Desk Workout",
                    description: "Complete a quick workout routine that can be done at your desk to boost energy.",
                    instructions: "Do 30 seconds each of desk push-ups, seated leg raises, shoulder rolls, torso twists, and deep breathing.",
                    estimatedTime: 5,
                    criteria: ["Complete all exercises with proper form", "Feel more energized after completion"],
                    hints: ["Focus on quality of movement rather than quantity."]
                },
                "mindfulness": {
                    title: "2-Minute Focused Breathing",
                    description: "Practice a quick mindfulness exercise using controlled breathing techniques.",
                    instructions: "Sit comfortably, close your eyes, and breathe in for 4 counts, hold for 2, exhale for the count of 6. Repeat for 2 minutes.",
                    estimatedTime: 5,
                    criteria: ["Maintained focus throughout exercise", "Noted any changes in mental state"],
                    hints: ["If your mind wanders, gently bring attention back to your breath without judgment."]
                },
                "writing": {
                    title: "Six-Word Story Challenge",
                    description: "Create a complete story using exactly six words.",
                    instructions: "Write a six-word story that has a beginning, middle, and end. Consider different genres or emotions.",
                    estimatedTime: 10,
                    criteria: ["Story is exactly six words", "Conveys a complete narrative arc"],
                    hints: ["Famous example: 'For sale: baby shoes, never worn.'"]
                }
            }
        };
        
        // Get appropriate challenge or default to beginner coding
        const challengesByDifficulty = fallbackChallenges[difficulty] || fallbackChallenges.beginner;
        const challenge = challengesByDifficulty[category] || challengesByDifficulty.coding;
        
        return {
            id: helpers.generateId(),
            title: challenge.title,
            description: challenge.description,
            instructions: challenge.instructions,
            difficulty: difficulty,
            category: category,
            estimatedTime: challenge.estimatedTime,
            criteria: challenge.criteria,
            hints: challenge.hints,
            resources: [],
            createdAt: new Date().toISOString(),
            xpPoints: this.calculateXPPoints(difficulty),
            badges: this.generateBadgesForChallenge(category, difficulty)
        };
    },

    /**
     * Evaluate a user's solution to a challenge
     * @param {Object} challenge - The challenge being solved
     * @param {string} solution - The user's solution
     * @returns {Promise<Object>} Evaluation results
     */
    async evaluateSolution(challenge, solution) {
        const messages = [
            {
                role: 'system',
                content: `You are an AI challenge evaluator for ChallengeCraft AI. 
                Your task is to evaluate the user's solution to the following challenge:
                
                Title: ${challenge.title}
                Description: ${challenge.description}
                Criteria: ${challenge.criteria.join(', ')}
                
                Provide constructive feedback and determine if the solution meets the success criteria.
                Structure your response as a JSON object with the following fields:
                - success: Boolean indicating whether the user successfully completed the challenge
                - score: A score from 0-100
                - feedback: Detailed feedback explaining strengths and weaknesses
                - improvedSolution: Optional suggestion for an improved solution
                - nextSteps: Suggestions for what to learn or practice next`
            },
            {
                role: 'user',
                content: `Challenge: ${challenge.title}\n\nMy solution:\n${solution}`
            }
        ];
        
        try {
            const completion = await this.generateChatCompletion(messages, null, {
                temperature: 0.7,
                max_tokens: 1000
            });
            
            const responseContent = completion.choices[0].message.content;
            let evaluation;
            
            try {
                // Try to parse the JSON response
                evaluation = JSON.parse(responseContent);
            } catch (parseError) {
                // If not valid JSON, extract the key information
                evaluation = {
                    success: responseContent.toLowerCase().includes('success') && !responseContent.toLowerCase().includes('not successful'),
                    score: this.extractScore(responseContent),
                    feedback: responseContent,
                    nextSteps: []
                };
            }
            
            return evaluation;
        } catch (error) {
            console.error('Error evaluating solution:', error);
            
            // Return a basic evaluation if API fails
            return {
                success: true,
                score: 70,
                feedback: "We couldn't evaluate your solution in detail due to a technical issue, but it looks good! Keep up the good work.",
                nextSteps: ["Try another challenge to continue improving your skills."]
            };
        }
    },

    /**
     * Extract a score from text
     * @param {string} text - The text to extract from
     * @returns {number} The extracted score (0-100)
     */
    extractScore(text) {
        // Look for a score pattern like "score: 85" or "85/100" or "85 out of 100"
        const scoreRegex = /score:?\s*(\d+)|(\d+)\s*\/\s*100|(\d+)\s*out\s*of\s*100/i;
        const match = text.match(scoreRegex);
        
        if (match) {
            const score = parseInt(match[1] || match[2] || match[3], 10);
            return Math.min(100, Math.max(0, score)); // Ensure between 0-100
        }
        
        // Default score if no pattern found
        return 70;
    },

    /**
     * Get a hint for the current challenge
     * @param {Object} challenge - The current challenge
     * @param {number} hintIndex - The index of the hint to reveal
     * @returns {string} The hint
     */
    getHint(challenge, hintIndex) {
        if (!challenge.hints || challenge.hints.length === 0) {
            return "No hints available for this challenge.";
        }
        
        if (hintIndex < 0 || hintIndex >= challenge.hints.length) {
            return challenge.hints[0];
        }
        
        return challenge.hints[hintIndex];
    }
};

// Initialize with site origin
document.addEventListener('DOMContentLoaded', () => {
    openRouter.init(window.location.origin, 'ChallengeCraft AI');
});

// Make openRouter available globally
window.openRouter = openRouter; 